import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Send, Trash2, Download, History, Cpu, Zap, MessageSquare, ShieldCheck, Terminal } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  tokens?: number;
  latency?: number;
}

export function AILabChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem('ailab_session');
    if (saved) setMessages(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('ailab_session', JSON.stringify(messages));
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now(),
      tokens: input.length / 4 // Rough estimate
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    const startTime = Date.now();
    
    try {
      // Simulate streaming and latency
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: input,
      });

      const latency = Date.now() - startTime;
      const content = response.text || "No response generated.";
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: '',
        timestamp: Date.now(),
        latency,
        tokens: content.length / 4
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Simulate streaming effect
      let currentContent = '';
      const words = content.split(' ');
      for (let i = 0; i < words.length; i++) {
        currentContent += words[i] + ' ';
        setMessages(prev => {
          const last = prev[prev.length - 1];
          return [...prev.slice(0, -1), { ...last, content: currentContent }];
        });
        await new Promise(r => setTimeout(r, 20 + Math.random() * 30));
      }

    } catch (error) {
      console.error(error);
    } finally {
      setIsTyping(false);
    }
  };

  const clearSession = () => {
    if (confirm('Clear current session?')) {
      setMessages([]);
      localStorage.removeItem('ailab_session');
    }
  };

  const exportSession = () => {
    const data = JSON.stringify(messages, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ailab-session-${Date.now()}.json`;
    a.click();
  };

  const totalTokens = messages.reduce((acc, m) => acc + (m.tokens || 0), 0);

  return (
    <div className="flex flex-col h-[600px] rounded-3xl border border-border bg-card/30 overflow-hidden">
      <header className="p-4 border-b border-border bg-muted/30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10 text-primary">
            <Terminal size={18} />
          </div>
          <div>
            <h3 className="text-sm font-bold">AI Inference Lab</h3>
            <div className="flex items-center gap-3 text-[10px] font-mono text-muted-foreground uppercase">
              <span className="flex items-center gap-1"><Cpu size={10} /> Gemini 3 Flash</span>
              <span className="flex items-center gap-1"><Zap size={10} /> {totalTokens.toFixed(0)} Tokens</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={exportSession} className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground" title="Export JSON">
            <Download size={16} />
          </button>
          <button onClick={clearSession} className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground" title="Clear Session">
            <Trash2 size={16} />
          </button>
          <button onClick={() => setShowHistory(!showHistory)} className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground" title="History">
            <History size={16} />
          </button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-6 space-y-6" ref={scrollRef}>
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-50">
            <MessageSquare size={48} className="text-muted-foreground" />
            <div className="space-y-1">
              <p className="text-sm font-bold">System Ready</p>
              <p className="text-xs font-mono">Input prompt to begin inference session.</p>
            </div>
          </div>
        )}
        {messages.map((msg) => (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`max-w-[80%] space-y-2 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <div className={`p-4 rounded-2xl text-sm leading-relaxed ${
                msg.role === 'user' 
                  ? 'bg-primary text-primary-foreground rounded-tr-none' 
                  : 'bg-muted border border-border rounded-tl-none'
              }`}>
                {msg.content}
              </div>
              <div className="flex items-center gap-3 px-1 text-[10px] font-mono text-muted-foreground uppercase">
                <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                {msg.latency && <span><Zap size={10} className="inline mr-1" /> {msg.latency}ms</span>}
                {msg.tokens && <span>{msg.tokens.toFixed(0)} tkn</span>}
              </div>
            </div>
          </motion.div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-muted border border-border p-4 rounded-2xl rounded-tl-none">
              <div className="flex gap-1">
                <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" />
                <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce [animation-delay:0.2s]" />
                <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          </div>
        )}
      </div>

      <footer className="p-4 border-t border-border bg-muted/30">
        <div className="relative">
          <input 
            type="text"
            placeholder="Enter system prompt..."
            className="w-full pl-4 pr-12 py-3 rounded-xl border border-border bg-background focus:ring-2 focus:ring-primary/20 outline-none transition-all font-mono text-sm"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <button 
            onClick={handleSend}
            disabled={isTyping || !input.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg bg-primary text-primary-foreground disabled:opacity-50 transition-all"
          >
            <Send size={16} />
          </button>
        </div>
        <div className="mt-2 flex items-center justify-between text-[10px] font-mono text-muted-foreground uppercase tracking-widest">
          <span className="flex items-center gap-1"><ShieldCheck size={10} /> End-to-End Encrypted</span>
          <span>Press Enter to Execute</span>
        </div>
      </footer>
    </div>
  );
}
