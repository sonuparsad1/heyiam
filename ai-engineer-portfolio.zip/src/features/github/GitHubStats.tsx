import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Github, GitCommit, Code, Star, GitFork, Activity } from 'lucide-react';

interface RepoStats {
  name: string;
  stars: number;
  forks: number;
  language: string;
}

interface GitHubData {
  commitCount: number;
  languages: Record<string, number>;
  repos: RepoStats[];
  totalStars: number;
}

const MOCK_GITHUB_DATA: GitHubData = {
  commitCount: 1248,
  languages: {
    TypeScript: 45,
    Python: 35,
    Rust: 10,
    Go: 10
  },
  repos: [
    { name: 'llm-inference-engine', stars: 450, forks: 82, language: 'Rust' },
    { name: 'distributed-rag-system', stars: 320, forks: 45, language: 'TypeScript' },
    { name: 'autonomous-agent-framework', stars: 280, forks: 38, language: 'Python' },
  ],
  totalStars: 1540
};

export function GitHubStats() {
  const [data, setData] = useState<GitHubData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API fetch with caching
    const cached = localStorage.getItem('github_stats');
    const now = Date.now();
    
    if (cached) {
      const { timestamp, payload } = JSON.parse(cached);
      if (now - timestamp < 3600000) { // 1 hour cache
        setData(payload);
        setLoading(false);
        return;
      }
    }

    const timer = setTimeout(() => {
      setData(MOCK_GITHUB_DATA);
      localStorage.setItem('github_stats', JSON.stringify({ timestamp: now, payload: MOCK_GITHUB_DATA }));
      setLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="h-32 rounded-2xl bg-muted animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={GitCommit} label="Total Commits" value={data?.commitCount || 0} />
        <StatCard icon={Star} label="Total Stars" value={data?.totalStars || 0} />
        <StatCard icon={Code} label="Languages" value={Object.keys(data?.languages || {}).length} />
        <StatCard icon={Activity} label="Contributions" value="Top 1%" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="p-8 rounded-3xl border border-border bg-card/30 space-y-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <Code size={20} className="text-primary" />
            Language Distribution
          </h3>
          <div className="space-y-4">
            {Object.entries(data?.languages || {}).map(([lang, percent]) => (
              <div key={lang} className="space-y-1">
                <div className="flex justify-between text-sm font-mono">
                  <span>{lang}</span>
                  <span>{percent}%</span>
                </div>
                <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${percent}%` }}
                    transition={{ duration: 1 }}
                    className="h-full bg-primary"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-8 rounded-3xl border border-border bg-card/30 space-y-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <Github size={20} className="text-primary" />
            Top Repositories
          </h3>
          <div className="space-y-4">
            {data?.repos.map(repo => (
              <div key={repo.name} className="flex items-center justify-between p-4 rounded-xl bg-muted/30 border border-border/50">
                <div className="space-y-1">
                  <div className="font-bold text-sm">{repo.name}</div>
                  <div className="text-[10px] font-mono text-muted-foreground uppercase">{repo.language}</div>
                </div>
                <div className="flex items-center gap-4 text-xs font-mono">
                  <span className="flex items-center gap-1"><Star size={12} /> {repo.stars}</span>
                  <span className="flex items-center gap-1"><GitFork size={12} /> {repo.forks}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value }: any) {
  return (
    <div className="p-6 rounded-2xl border border-border bg-card/50 backdrop-blur-sm">
      <div className="p-2 rounded-lg bg-primary/10 text-primary w-fit mb-4">
        <Icon size={20} />
      </div>
      <div className="text-xs font-mono text-muted-foreground uppercase tracking-widest mb-1">{label}</div>
      <div className="text-2xl font-bold tracking-tight">{value}</div>
    </div>
  );
}
