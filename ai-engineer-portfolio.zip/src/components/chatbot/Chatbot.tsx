import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageCircle, X, Send, Bot, Trash2, Settings2, Image as LucideImage, Video, BrainCircuit, Paperclip, Loader2 } from "lucide-react";
import { Button } from "../ui/Button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../ui/Card";
import { useAppStore } from "../../store/useStore";
import { generateAIResponse, ChatMessage, getChatHistory, clearChatHistory } from "../../services/aiService";

type ChatMode = "chat" | "image" | "video";

export function Chatbot() {
  const { isChatOpen, toggleChat } = useAppStore();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [mode, setMode] = useState<ChatMode>("chat");
  const [useThinking, setUseThinking] = useState(false);
  const [aspectRatio, setAspectRatio] = useState("1:1");
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const loadHistory = async () => {
      try {
        const history = await getChatHistory();
        if (history.length > 0) {
          setMessages(history);
        } else {
          setMessages([{ role: "model", text: "Hello! I am Gemini, acting as Sonu's personal portfolio assistant. I can help you explore his work, or assist with creative tasks like analyzing content or generating assets. How can I help?" }]);
        }
      } catch (e) {
        console.error("Failed to load chat history", e);
      }
    };
    loadHistory();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isChatOpen) scrollToBottom();
  }, [isChatOpen]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const clearChat = async () => {
    try {
      await clearChatHistory();
      const initialMsg: ChatMessage = { role: "model", text: "Chat cleared. Ready for new tasks." };
      setMessages([initialMsg]);
    } catch (e) {
      console.error("Failed to clear chat", e);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAttachedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async () => {
    if (!input.trim() && !attachedImage) return;

    const userMessage: ChatMessage = { 
      role: "user", 
      text: input,
      images: attachedImage ? [attachedImage] : undefined
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setAttachedImage(null);
    setIsLoading(true);

    try {
      let responseText = "";
      
      if (mode === "image") {
        responseText = await generateAIResponse(input, { mode: 'image', aspectRatio });
        // The backend returns the base64 image string for image mode
        setMessages(prev => [...prev, { role: "model", text: `Here is your generated image for: "${input}"`, images: [responseText] }]);
      } else if (mode === "video") {
        responseText = await generateAIResponse(input, { mode: 'video', images: userMessage.images, aspectRatio });
        setMessages(prev => [...prev, { role: "model", text: `Here is your generated video for: "${input}"\n\n${responseText}` }]);
      } else {
        responseText = await generateAIResponse(input, { 
          images: userMessage.images, 
          useThinking,
          mode: 'text'
        });
        setMessages(prev => [...prev, { role: "model", text: responseText }]);
      }
    } catch (error: any) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, { role: "model", text: `Error: ${error.message || "Something went wrong."}` }]);
    } finally {
      setIsLoading(false);
    }
  };

  const renderMessageContent = (msg: ChatMessage) => {
    if (!msg || typeof msg !== 'object') return null;
    
    // Check for video marker
    const textContent = msg.text || "";
    const videoMatch = textContent.match(/\[VIDEO\](.*?)\[\/VIDEO\]/);
    let text = textContent;
    let videoUrl = null;
    
    if (videoMatch) {
      videoUrl = videoMatch[1];
      text = text.replace(videoMatch[0], "");
    }

    return (
      <div className="space-y-2">
        {msg.images?.map((img, idx) => (
          <img key={idx} src={img} alt="Attached" className="max-w-full rounded-lg border border-border/50" />
        ))}
        {videoUrl && (
          <video controls src={videoUrl} className="max-w-full rounded-lg border border-border/50 w-full" />
        )}
        <div className="whitespace-pre-wrap">{text}</div>
      </div>
    );
  };

  return (
    <>
      <AnimatePresence>
        {!isChatOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={toggleChat}
            className="fixed bottom-6 right-6 z-50 p-4 bg-primary text-primary-foreground rounded-full shadow-lg hover:shadow-primary/25 transition-shadow"
          >
            <MessageCircle className="h-6 w-6" />
          </motion.button>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isChatOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 w-[90vw] md:w-[450px] h-[650px] max-h-[85vh]"
          >
            <Card className="h-full flex flex-col shadow-2xl border-primary/20 overflow-hidden bg-background/95 backdrop-blur-md">
              <CardHeader className="p-3 border-b bg-muted/30 flex flex-row items-center justify-between space-y-0">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${useThinking ? 'bg-purple-500/10 text-purple-500' : 'bg-primary/10 text-primary'}`}>
                    {useThinking ? <BrainCircuit className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
                  </div>
                  <div>
                    <CardTitle className="text-base">AI Assistant</CardTitle>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      {mode === 'chat' ? (useThinking ? 'Deep Thinking Mode' : 'Gemini Pro') : mode === 'image' ? 'Image Generation' : 'Veo Video Gen'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowSettings(!showSettings)}>
                    <Settings2 className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={toggleChat}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>

              <AnimatePresence>
                {showSettings && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="bg-muted/50 border-b overflow-hidden"
                  >
                    <div className="p-4 space-y-4">
                      <div className="grid grid-cols-3 gap-2">
                        <button
                          onClick={() => setMode('chat')}
                          className={`flex flex-col items-center gap-1 p-2 rounded-lg border transition-all ${mode === 'chat' ? 'bg-background border-primary text-primary' : 'border-transparent hover:bg-background/50'}`}
                        >
                          <MessageCircle className="h-4 w-4" />
                          <span className="text-[10px] font-medium">Chat</span>
                        </button>
                        <button
                          onClick={() => setMode('image')}
                          className={`flex flex-col items-center gap-1 p-2 rounded-lg border transition-all ${mode === 'image' ? 'bg-background border-primary text-primary' : 'border-transparent hover:bg-background/50'}`}
                        >
                          <LucideImage className="h-4 w-4" />
                          <span className="text-[10px] font-medium">Image</span>
                        </button>
                        <button
                          onClick={() => setMode('video')}
                          className={`flex flex-col items-center gap-1 p-2 rounded-lg border transition-all ${mode === 'video' ? 'bg-background border-primary text-primary' : 'border-transparent hover:bg-background/50'}`}
                        >
                          <Video className="h-4 w-4" />
                          <span className="text-[10px] font-medium">Video</span>
                        </button>
                      </div>

                      {mode === 'chat' && (
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-medium">Deep Thinking (Gemini 3.1)</label>
                          <button 
                            onClick={() => setUseThinking(!useThinking)}
                            className={`w-10 h-5 rounded-full transition-colors relative ${useThinking ? 'bg-primary' : 'bg-muted-foreground/30'}`}
                          >
                            <div className={`absolute top-1 left-1 w-3 h-3 bg-white rounded-full transition-transform ${useThinking ? 'translate-x-5' : ''}`} />
                          </button>
                        </div>
                      )}

                      {(mode === 'image' || mode === 'video') && (
                        <div className="space-y-2">
                          <label className="text-xs font-medium">Aspect Ratio</label>
                          <select 
                            value={aspectRatio} 
                            onChange={(e) => setAspectRatio(e.target.value)}
                            className="w-full text-xs bg-background border rounded-md p-2"
                          >
                            <option value="1:1">1:1 (Square)</option>
                            <option value="16:9">16:9 (Landscape)</option>
                            <option value="9:16">9:16 (Portrait)</option>
                            <option value="4:3">4:3 (Standard)</option>
                            <option value="3:4">3:4 (Portrait Standard)</option>
                          </select>
                        </div>
                      )}

                      <Button variant="outline" size="sm" className="w-full gap-2 h-8 text-xs text-destructive hover:bg-destructive/10 border-destructive/20" onClick={clearChat}>
                        <Trash2 className="h-3 w-3" /> Clear History
                      </Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <CardContent className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-primary/10 scrollbar-track-transparent">
                {messages.map((msg, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm shadow-sm ${
                        msg.role === "user"
                          ? "bg-primary text-primary-foreground rounded-br-none"
                          : "bg-muted text-foreground rounded-bl-none border border-border/50"
                      }`}
                    >
                      {renderMessageContent(msg)}
                    </div>
                  </motion.div>
                ))}
                {isLoading && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex justify-start"
                  >
                    <div className="bg-muted rounded-2xl rounded-bl-none px-4 py-3 border border-border/50 flex gap-2 items-center text-xs text-muted-foreground">
                      <Loader2 className="h-3 w-3 animate-spin" />
                      {mode === 'video' ? 'Generating video (this takes a while)...' : mode === 'image' ? 'Creating image...' : useThinking ? 'Thinking deeply...' : 'Typing...'}
                    </div>
                  </motion.div>
                )}
                <div ref={messagesEndRef} />
              </CardContent>

              <CardFooter className="p-3 border-t bg-background flex-col gap-2">
                {attachedImage && (
                  <div className="w-full flex items-center justify-between bg-muted/50 p-2 rounded-lg">
                    <div className="flex items-center gap-2">
                      <img src={attachedImage} alt="Preview" className="h-8 w-8 rounded object-cover" />
                      <span className="text-xs text-muted-foreground">Image attached</span>
                    </div>
                    <button onClick={() => setAttachedImage(null)} className="text-muted-foreground hover:text-destructive">
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                )}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSend();
                  }}
                  className="flex w-full gap-2 items-end"
                >
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                  />
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon" 
                    className="h-10 w-10 shrink-0 rounded-full"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={mode === 'image' ? "Describe image to generate..." : mode === 'video' ? "Describe video..." : "Ask anything..."}
                    className="flex-1 bg-muted/50 border-0 rounded-2xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/20 focus:outline-none transition-all min-h-[40px]"
                    disabled={isLoading}
                  />
                  <Button 
                    type="submit" 
                    size="icon" 
                    className="rounded-full h-10 w-10 shrink-0" 
                    disabled={isLoading || (!input.trim() && !attachedImage)}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </form>
              </CardFooter>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
