import { create } from 'zustand';

interface AppState {
  isChatOpen: boolean;
  toggleChat: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  isChatOpen: false,
  toggleChat: () => set((state) => ({ isChatOpen: !state.isChatOpen })),
}));
