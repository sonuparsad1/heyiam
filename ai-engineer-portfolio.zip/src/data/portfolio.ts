export const portfolioData = {
  name: "Sonu Parsad",
  role: "AI Developer / Machine Learning Engineer",
  education: {
    degree: "Bachelor of Technology (B.Tech)",
    major: "Computer Science & Engineering",
    institution: "Lovely Professional University",
    duration: "2025 - Present",
    keyAreas: [
      "Data Structures & Algorithms",
      "Operating Systems",
      "Database Management Systems",
      "Programming Fundamentals",
      "Software Engineering Principles"
    ]
  },
  careerObjective: "To become a skilled AI Developer and Machine Learning Engineer by strengthening core computer science fundamentals, building real-world technical projects, developing strong problem-solving ability, understanding AI systems at architectural and algorithmic levels, and contributing to impactful AI-driven applications.",
  skills: {
    programmingLanguages: [
      { name: "C++", level: "Intermediate", details: "Data structures, problem solving" },
      { name: "Python", level: "Advanced", details: "Scripting, AI/ML fundamentals" },
      { name: "JavaScript", level: "Intermediate", details: "Frontend interaction" }
    ],
    csFundamentals: [
      "Data Structures (Arrays, Linked Lists, Stack, Queue)",
      "Algorithms (Search, Sort, Big-O)",
      "Operating Systems (Process, Thread, Memory)",
      "Database Management Systems (SQL, Normalization)"
    ],
    currentFocus: [
      "Improving Data Structures depth in C++",
      "Practicing competitive programming problems",
      "Strengthening algorithmic thinking",
      "Understanding machine learning concepts theoretically",
      "Learning how AI systems are architected",
      "Building structured AI roadmap"
    ]
  },
  projects: [
    {
      title: "Smart Urinal Blockage Detection & Alert System",
      category: "Hardware / IoT",
      description: "Hardware-software integrated system using ultrasonic sensors and Arduino to detect blockages and send alerts.",
      tech: ["Arduino", "C++", "Ultrasonic Sensors", "IoT"]
    },
    {
      title: "Neural Network Visualizer",
      category: "AI",
      description: "Interactive web app to visualize forward and backward propagation in a neural network.",
      tech: ["React", "TensorFlow.js", "D3.js"]
    },
    {
      title: "Predictive Maintenance Dashboard",
      category: "IoT",
      description: "IoT dashboard predicting machine failures using sensor data and Random Forest.",
      tech: ["Python", "Flask", "React", "Scikit-Learn"]
    },
    {
      title: "Algorithmic Trading Bot",
      category: "AI",
      description: "Reinforcement learning bot for trading crypto using historical binance data.",
      tech: ["PyTorch", "Pandas", "Binance API"]
    },
    {
      title: "Smart Portfolio",
      category: "Web",
      description: "A modern, animated portfolio built with React and Tailwind CSS.",
      tech: ["React", "Tailwind", "Framer Motion"]
    },
    {
      title: "DSA Visualizer",
      category: "DSA",
      description: "Visualizing sorting and pathfinding algorithms.",
      tech: ["JavaScript", "HTML5 Canvas"]
    }
  ],
  contact: {
    email: "hello@example.com",
    github: "github.com/sonuparsad",
    linkedin: "linkedin.com/in/sonuparsad"
  }
};
