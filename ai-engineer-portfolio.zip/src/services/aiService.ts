export interface ChatMessage {
  role: "user" | "model";
  text: string;
  images?: string[]; // base64 strings
}

const getSessionId = () => {
  let sessionId = localStorage.getItem("chat_session_id");
  if (!sessionId) {
    sessionId = Math.random().toString(36).substring(2, 15);
    localStorage.setItem("chat_session_id", sessionId);
  }
  return sessionId;
};

export const getChatHistory = async () => {
  const sessionId = getSessionId();
  const response = await fetch(`/api/history/${sessionId}`);
  if (!response.ok) return [];
  const data = await response.json();
  return data.map((h: any) => ({
    role: h.role,
    text: h.content,
    images: h.images ? JSON.parse(h.images) : []
  }));
};

export const clearChatHistory = async () => {
  const sessionId = getSessionId();
  await fetch(`/api/history/${sessionId}`, { method: "DELETE" });
};

export const generateAIResponse = async (
  prompt: string,
  options: {
    images?: string[];
    mode?: 'text' | 'image' | 'video';
    aspectRatio?: string;
    useThinking?: boolean;
  } = {}
) => {
  const sessionId = getSessionId();
  
  // Check for paid key if needed
  let apiKey = "";
  if (options.mode === 'image' || options.mode === 'video' || options.useThinking) {
    // @ts-ignore
    if (window.aistudio && window.aistudio.hasSelectedApiKey) {
      // @ts-ignore
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (!hasKey) {
        // @ts-ignore
        await window.aistudio.openSelectKey();
      }
    }
  }

  const response = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      sessionId,
      prompt,
      images: options.images || [],
      mode: options.mode || 'text',
      aspectRatio: options.aspectRatio || '1:1',
      useThinking: options.useThinking || false,
      apiKey
    })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to generate response");
  }

  const data = await response.json();
  let text = data.text;

  // Handle video proxying if needed
  if (options.mode === 'video' && text.includes('[VIDEO]')) {
    const uri = text.match(/\[VIDEO\](.*?)\[\/VIDEO\]/)?.[1];
    if (uri) {
      const proxyUrl = `/api/proxy/video?uri=${encodeURIComponent(uri)}${apiKey ? `&apiKey=${encodeURIComponent(apiKey)}` : ''}`;
      text = text.replace(/\[VIDEO\].*?\[\/VIDEO\]/, `[VIDEO]${proxyUrl}[/VIDEO]`);
    }
  }

  return text;
};
