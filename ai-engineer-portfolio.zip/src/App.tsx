import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { Layout } from './components/layout/Layout';
import { ErrorBoundary } from 'react-error-boundary';

// Lazy load pages for code splitting
const Home = lazy(() => import('./pages/Home'));
const Projects = lazy(() => import('./pages/Projects'));
const Blog = lazy(() => import('./pages/Blog'));
const AILab = lazy(() => import('./pages/AILab'));
const About = lazy(() => import('./pages/About'));
const EngineeringMetrics = lazy(() => import('./pages/EngineeringMetrics'));
const Research = lazy(() => import('./pages/Research'));
const SystemDesign = lazy(() => import('./pages/SystemDesign'));
const PortfolioArchitecture = lazy(() => import('./pages/PortfolioArchitecture'));
const NotFound = lazy(() => import('./pages/NotFound'));

const PageTransition = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, y: 10, filter: 'blur(10px)' }}
        animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
        exit={{ opacity: 0, y: -10, filter: 'blur(10px)' }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
};

const ErrorFallback = ({ error }: { error: any }) => (
  <div className="min-h-screen flex items-center justify-center p-4 bg-background text-foreground">
    <div className="max-w-md w-full p-8 rounded-3xl border border-border bg-card space-y-4">
      <h2 className="text-2xl font-bold">System Error</h2>
      <p className="text-muted-foreground font-mono text-sm">{error.message}</p>
      <button 
        onClick={() => window.location.reload()}
        className="w-full py-2 rounded-xl bg-primary text-primary-foreground font-bold hover:bg-primary/90 transition-colors"
      >
        Reboot System
      </button>
    </div>
  </div>
);

const LoadingFallback = () => (
  <div className="min-h-[60vh] flex flex-col items-center justify-center space-y-4">
    <div className="relative h-12 w-12">
      <div className="absolute inset-0 border-4 border-primary/20 rounded-full" />
      <div className="absolute inset-0 border-4 border-primary border-t-transparent rounded-full animate-spin" />
    </div>
    <div className="text-xs font-mono text-muted-foreground uppercase tracking-widest animate-pulse">
      Initializing Modules...
    </div>
  </div>
);

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="projects" element={<Projects />} />
        <Route path="blog" element={<Blog />} />
        <Route path="playground" element={<AILab />} />
        <Route path="about" element={<About />} />
        <Route path="engineering-metrics" element={<EngineeringMetrics />} />
        <Route path="research" element={<Research />} />
        <Route path="system-design" element={<SystemDesign />} />
        <Route path="architecture" element={<PortfolioArchitecture />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}

function App() {
  return (
    <ErrorBoundary FallbackComponent={ErrorFallback}>
      <Router>
        <Suspense fallback={<LoadingFallback />}>
          <PageTransition>
            <AppRoutes />
          </PageTransition>
        </Suspense>
      </Router>
    </ErrorBoundary>
  );
}

export default App;
