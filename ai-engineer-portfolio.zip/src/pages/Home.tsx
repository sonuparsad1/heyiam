import { motion } from "motion/react";
import Typewriter from "typewriter-effect";
import { ArrowRight, Code2, BrainCircuit, Sparkles, Network } from "lucide-react";
import { Button } from "../components/ui/Button";
import { Link } from "react-router-dom";
import { useInView } from "react-intersection-observer";

export default function Home() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <div className="flex flex-col gap-20 py-10 relative overflow-hidden">
      {/* Animated Background Grid */}
      <div className="absolute inset-0 -z-20 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]" />
      
      {/* Hero Section */}
      <section className="relative min-h-[85vh] flex flex-col justify-center items-center text-center">
        <div className="absolute inset-0 -z-10 bg-background opacity-70" />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-8 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/5 border border-primary/20 text-sm font-medium backdrop-blur-sm shadow-sm"
        >
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-primary"></span>
          </span>
          Available for Hire
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.7, ease: "easeOut" }}
          className="text-5xl md:text-7xl lg:text-8xl font-extrabold tracking-tight mb-6"
        >
          Hi, I'm <span className="text-primary">Sonu Parsad</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.7, ease: "easeOut" }}
          className="text-xl md:text-3xl text-muted-foreground font-medium mb-8 h-12 flex items-center justify-center gap-2"
        >
          <BrainCircuit className="h-6 w-6 text-primary animate-pulse" />
          <Typewriter
            options={{
              strings: [
                "AI Developer",
                "Machine Learning Engineer",
                "Full-Stack Architect",
                "Systems Thinker",
              ],
              autoStart: true,
              loop: true,
              delay: 50,
              deleteSpeed: 30,
            }}
          />
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.7, ease: "easeOut" }}
          className="max-w-2xl text-lg md:text-xl text-muted-foreground mb-10 leading-relaxed"
        >
          I build robust, scalable AI architectures and intelligent systems. Passionate about moving beyond scripts to engineer production-grade machine learning solutions.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.7, ease: "easeOut" }}
          className="flex flex-wrap items-center justify-center gap-4"
        >
          <Button asChild size="lg" className="gap-2 h-12 px-8 rounded-full shadow-lg shadow-primary/20 hover:shadow-primary/40 transition-all">
            <Link to="/projects">
              View Architecture <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="gap-2 h-12 px-8 rounded-full backdrop-blur-sm border-primary/20 hover:bg-primary/5">
            <Link to="/playground">
              <Sparkles className="h-4 w-4 text-primary" /> Enter AI Lab
            </Link>
          </Button>
        </motion.div>
      </section>

      {/* Stats Section */}
      <section ref={ref} className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
        {[
          { icon: Network, label: "Systems Architected", value: "15+" },
          { icon: BrainCircuit, label: "Models Deployed", value: "10+" },
          { icon: Code2, label: "Lines of Code", value: "100k+" },
        ].map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 40 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
            transition={{ delay: i * 0.15, duration: 0.6, ease: "easeOut" }}
            className="group p-8 rounded-3xl border border-border/50 bg-card/50 backdrop-blur-sm text-card-foreground flex items-center gap-6 hover:border-primary/30 hover:bg-card/80 transition-all duration-300 shadow-sm hover:shadow-md"
          >
            <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300">
              <stat.icon className="h-7 w-7" />
            </div>
            <div>
              <h3 className="text-4xl font-bold tracking-tight mb-1">{stat.value}</h3>
              <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{stat.label}</p>
            </div>
          </motion.div>
        ))}
      </section>
    </div>
  );
}
