import { useState, useMemo, useCallback } from "react";
import { motion } from "motion/react";
import { List } from "react-window";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Github, ExternalLink, Layers, ShieldCheck, Zap, Share2 } from "lucide-react";

const projects = Array.from({ length: 50 }, (_, i) => ({
  id: i + 1,
  title: i % 3 === 0 ? "Distributed LLM Inference Engine" : i % 3 === 1 ? "Autonomous RAG Pipeline" : "Real-time Edge Vision System",
  category: ["AI Systems", "MLOps", "Edge AI"][i % 3],
  description: "A high-performance system designed for low-latency inference across heterogeneous GPU clusters, implementing custom PagedAttention kernels.",
  tech: ["Rust", "CUDA", "Python", "Kubernetes", "gRPC"],
  architecture: "Multi-node distributed architecture with a centralized scheduler and decentralized inference workers using RDMA for zero-copy data transfer.",
  challenges: "Handling memory fragmentation in KV-caches and minimizing inter-node communication overhead during multi-GPU tensor parallelism.",
  metrics: { latency: "45ms", throughput: "1.2k t/s", uptime: "99.99%" },
  github: "#",
  live: "#",
  image: `https://picsum.photos/seed/project-${i}/600/400?blur=2`
}));

const categories = ["All", "AI Systems", "MLOps", "Edge AI"];

export default function Projects() {
  const [filter, setFilter] = useState("All");

  const filteredProjects = useMemo(() => {
    return projects.filter((p) => filter === "All" || p.category === filter);
  }, [filter]);

  const Row = useCallback(({ index, style }: any) => {
    const project = filteredProjects[index];
    if (!project) return null;

    return (
      <div style={style} className="px-4 py-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="h-full"
        >
          <Card className="overflow-hidden h-full flex flex-col md:flex-row group hover:border-primary/50 transition-all duration-500 bg-card/30 border-border">
            <div className="relative w-full md:w-1/3 h-64 md:h-auto overflow-hidden">
              <img
                src={project.image}
                alt={project.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-background/60" />
              <div className="absolute top-4 left-4">
                <span className="text-[10px] font-bold px-3 py-1 bg-primary text-primary-foreground rounded-full uppercase tracking-widest shadow-lg">
                  {project.category}
                </span>
              </div>
            </div>
            
            <div className="flex-1 flex flex-col">
              <CardHeader className="pt-6">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-2xl font-extrabold tracking-tight group-hover:text-primary transition-colors">
                    {project.title}
                  </CardTitle>
                  <div className="flex gap-2">
                    <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full hover:bg-primary hover:text-primary-foreground" asChild>
                      <a href={project.github} target="_blank" rel="noreferrer"><Github size={16} /></a>
                    </Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full hover:bg-primary hover:text-primary-foreground" asChild>
                      <a href={project.live} target="_blank" rel="noreferrer"><ExternalLink size={16} /></a>
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="flex-1 space-y-6">
                <p className="text-sm text-muted-foreground leading-relaxed max-w-2xl">
                  {project.description}
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-primary">
                      <Share2 size={12} /> Architecture
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {project.architecture}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-primary">
                      <ShieldCheck size={12} /> Core Challenge
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {project.challenges}
                    </p>
                  </div>
                </div>

                <div className="flex gap-6 pt-2 border-t border-border/50">
                  {Object.entries(project.metrics).map(([key, val]) => (
                    <div key={key} className="space-y-1">
                      <div className="text-[10px] font-mono text-muted-foreground uppercase">{key}</div>
                      <div className="text-sm font-bold flex items-center gap-1">
                        <Zap size={10} className="text-primary" /> {val}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              
              <CardFooter className="pt-4 border-t border-border/50 bg-muted/10">
                <div className="flex flex-wrap gap-2">
                  {project.tech.map((t) => (
                    <span key={t} className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-secondary text-secondary-foreground border border-border/50 uppercase">
                      {t}
                    </span>
                  ))}
                </div>
              </CardFooter>
            </div>
          </Card>
        </motion.div>
      </div>
    );
  }, [filteredProjects]);

  return (
    <div className="max-w-7xl mx-auto py-12 space-y-12">
      <header className="space-y-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-mono uppercase tracking-widest"
        >
          <Layers size={12} />
          Systems Engineering
        </motion.div>
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">Project Portfolio</h1>
        <p className="text-xl text-muted-foreground max-w-3xl">
          A selection of my recent work, highlighting architectural decisions and technical implementations across AI, Web, and Hardware.
        </p>
      </header>

      <div className="flex flex-wrap gap-3">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`px-5 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${
              filter === cat 
                ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" 
                : "bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="h-[1000px] w-full">
        <List
          style={{ height: 1000 }}
          rowCount={filteredProjects.length}
          rowHeight={450}
          rowComponent={Row}
          rowProps={{}}
          className="hide-scrollbar"
        />
      </div>
    </div>
  );
}
