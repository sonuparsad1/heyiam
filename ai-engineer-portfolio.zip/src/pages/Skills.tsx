import { motion } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Download, Code2, Database, Cpu, Target, BarChart3 } from "lucide-react";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
} from "recharts";

const programmingLanguages = [
  {
    name: "C++",
    level: 60,
    details: [
      "Understanding of basic syntax and structure",
      "Comfortable with loops, functions, conditionals",
      "Learning data structures implementation",
      "Practicing problem-solving questions"
    ]
  },
  {
    name: "Python",
    level: 70,
    details: [
      "Strong grasp of syntax",
      "Writing scripts and logical programs",
      "Understanding modules and standard libraries",
      "Exploring AI/ML fundamentals conceptually"
    ]
  },
  {
    name: "JavaScript",
    level: 50,
    details: [
      "Basic knowledge for frontend interaction",
      "Understanding of variables, functions, and DOM concepts"
    ]
  }
];

const csFundamentals = [
  {
    category: "Data Structures (Learning Phase)",
    icon: <Code2 className="h-5 w-5 text-primary" />,
    items: ["Arrays", "Linked Lists (basic understanding)", "Stack", "Queue"]
  },
  {
    category: "Algorithms",
    icon: <Target className="h-5 w-5 text-primary" />,
    items: ["Linear Search", "Binary Search", "Basic Sorting (Bubble, Selection)", "Time complexity awareness (Big-O basics)"]
  },
  {
    category: "Operating Systems (Theory Level)",
    icon: <Cpu className="h-5 w-5 text-primary" />,
    items: ["Process vs Thread concept", "Basic memory management understanding", "Role of OS in program execution"]
  },
  {
    category: "Database Management Systems (Theory Level)",
    icon: <Database className="h-5 w-5 text-primary" />,
    items: ["What is DBMS", "Basic SQL understanding", "Normalization concept awareness"]
  }
];

const currentLearningFocus = [
  "Improving Data Structures depth in C++",
  "Practicing competitive programming problems",
  "Strengthening algorithmic thinking",
  "Understanding machine learning concepts theoretically",
  "Learning how AI systems are architected",
  "Building structured AI roadmap"
];

const skillMatrix = [
  { subject: "C++", A: 60, fullMark: 100 },
  { subject: "Python", A: 70, fullMark: 100 },
  { subject: "JavaScript", A: 50, fullMark: 100 },
  { subject: "DSA", A: 40, fullMark: 100 },
  { subject: "Algorithms", A: 45, fullMark: 100 },
  { subject: "OS/DBMS", A: 30, fullMark: 100 },
];

export default function Skills() {
  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <h1 className="text-4xl font-bold tracking-tight">Technical Skills</h1>
          <p className="text-muted-foreground mt-2">
            My current foundation and learning progress.
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <Button className="gap-2">
            <Download className="h-4 w-4" /> Download Skill Matrix
          </Button>
        </motion.div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-6"
        >
          <h2 className="text-2xl font-semibold flex items-center gap-2">
            🧩 Programming Languages
          </h2>
          {programmingLanguages.map((lang, i) => (
            <Card key={lang.name}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg">{lang.name}</CardTitle>
                  <span className="text-sm text-muted-foreground">Learning Progress</span>
                </div>
                <div className="h-2 w-full bg-secondary rounded-full overflow-hidden mt-2">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${lang.level}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, ease: "easeOut", delay: i * 0.2 }}
                    className="h-full bg-primary rounded-full"
                  />
                </div>
              </CardHeader>
              <CardContent>
                <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                  {lang.details.map((detail, j) => (
                    <li key={j}>{detail}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        <div className="space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            <h2 className="text-2xl font-semibold flex items-center gap-2">
              <BarChart3 className="h-6 w-6 text-primary" /> Skill Matrix
            </h2>
            <Card className="h-[350px] w-full flex items-center justify-center p-4">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={skillMatrix}>
                  <PolarGrid stroke="currentColor" className="text-muted-foreground/30" />
                  <PolarAngleAxis
                    dataKey="subject"
                    tick={{ fill: "currentColor", fontSize: 12 }}
                    className="text-muted-foreground"
                  />
                  <PolarRadiusAxis
                    angle={30}
                    domain={[0, 100]}
                    tick={{ fill: "currentColor", fontSize: 10 }}
                    className="text-muted-foreground/50"
                  />
                  <Radar
                    name="Skills"
                    dataKey="A"
                    stroke="hsl(var(--primary))"
                    fill="hsl(var(--primary))"
                    fillOpacity={0.3}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            <h2 className="text-2xl font-semibold flex items-center gap-2">
              🧠 CS Fundamentals
            </h2>
            <div className="grid sm:grid-cols-2 gap-4">
              {csFundamentals.map((fund, i) => (
                <Card key={i} className="h-full">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      {fund.icon} {fund.category}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                      {fund.items.map((item, j) => (
                        <li key={j}>{item}</li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="bg-primary/5 border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  🎯 Current Learning Focus
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {currentLearningFocus.map((focus, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                      <span>{focus}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
