import { motion } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Download, FileText, ExternalLink, ShieldCheck } from "lucide-react";

export default function Resume() {
  return (
    <div className="max-w-5xl mx-auto space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-2"
        >
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Curriculum Vitae</h1>
          <p className="text-lg text-muted-foreground max-w-xl">
            A comprehensive overview of my academic background, technical skills, and engineering experience.
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex flex-wrap gap-3"
        >
          <Button className="gap-2 rounded-full shadow-md shadow-primary/10 hover:shadow-primary/20 transition-all">
            <Download className="h-4 w-4" /> Download PDF
          </Button>
          <Button variant="outline" className="gap-2 rounded-full border-primary/20 hover:bg-primary/5 transition-all">
            <ExternalLink className="h-4 w-4" /> Open in New Tab
          </Button>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        <Card className="overflow-hidden border border-border/50 shadow-xl shadow-black/5 bg-card/50 backdrop-blur-sm">
          <CardHeader className="bg-muted/30 border-b border-border/50 flex flex-row items-center justify-between py-4">
            <CardTitle className="flex items-center gap-2 text-lg font-medium">
              <FileText className="h-5 w-5 text-primary" /> sonu_parsad_resume.pdf
            </CardTitle>
            <div className="flex items-center gap-2 text-xs font-medium text-emerald-500 bg-emerald-500/10 px-3 py-1 rounded-full">
              <ShieldCheck className="h-3.5 w-3.5" /> Verified
            </div>
          </CardHeader>
          <CardContent className="p-0 bg-secondary/10 h-[700px] flex items-center justify-center relative overflow-hidden">
            {/* Decorative background elements */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-20">
              <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-primary/30 blur-[100px]" />
              <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-blue-500/20 blur-[100px]" />
            </div>

            {/* Placeholder for actual PDF embed */}
            <div className="text-center space-y-6 p-8 relative z-10 max-w-md mx-auto bg-background/80 backdrop-blur-md rounded-2xl border border-border/50 shadow-2xl">
              <div className="h-20 w-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="h-10 w-10 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold">Resume Viewer</h3>
                <p className="text-muted-foreground">
                  Interactive PDF rendering is currently disabled in this preview environment.
                </p>
              </div>
              <div className="p-4 bg-muted/50 rounded-xl text-sm text-muted-foreground text-left space-y-3 border border-border/50">
                <p className="font-medium text-foreground flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-emerald-500" /> Production Implementation:
                </p>
                <p>
                  In a production environment, this component utilizes <code className="text-xs bg-background px-1 py-0.5 rounded border">react-pdf</code> or a secure iframe to render the document directly within the browser, supporting text selection and search.
                </p>
              </div>
              <Button className="w-full gap-2 mt-4" variant="outline">
                <Download className="h-4 w-4" /> Download to View
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
