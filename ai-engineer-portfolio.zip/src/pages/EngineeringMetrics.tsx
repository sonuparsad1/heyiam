import { motion } from 'motion/react';
import { 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  BarChart, Bar, AreaChart, Area 
} from 'recharts';
import { Activity, Cpu, Zap, Database, ShieldCheck, BarChart3 } from 'lucide-react';

const LATENCY_DATA = [
  { model: 'Gemini 1.5 Flash', latency: 450, tps: 120 },
  { model: 'Gemini 1.5 Pro', latency: 1200, tps: 45 },
  { model: 'GPT-4o', latency: 850, tps: 65 },
  { model: 'Claude 3.5 Sonnet', latency: 950, tps: 55 },
  { model: 'Llama 3 70B', latency: 1100, tps: 40 },
];

const TOKEN_USAGE = [
  { month: 'Jan', prompt: 45000, completion: 12000 },
  { month: 'Feb', prompt: 52000, completion: 15000 },
  { month: 'Mar', prompt: 48000, completion: 14000 },
  { month: 'Apr', prompt: 61000, completion: 18000 },
  { month: 'May', prompt: 55000, completion: 16000 },
  { month: 'Jun', prompt: 67000, completion: 21000 },
];

const RAG_PERFORMANCE = [
  { name: 'Precision', value: 92 },
  { name: 'Recall', value: 88 },
  { name: 'Faithfulness', value: 95 },
  { name: 'Relevance', value: 91 },
];

const MetricCard = ({ title, value, unit, icon: Icon, trend }: any) => (
  <motion.div 
    whileHover={{ y: -5 }}
    className="p-6 rounded-2xl border border-border bg-card/50 backdrop-blur-sm"
  >
    <div className="flex justify-between items-start mb-4">
      <div className="p-2 rounded-lg bg-primary/10 text-primary">
        <Icon size={20} />
      </div>
      {trend && (
        <span className="text-xs font-mono text-muted-foreground">
          {trend > 0 ? '+' : ''}{trend}%
        </span>
      )}
    </div>
    <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-1">{title}</h3>
    <div className="flex items-baseline gap-1">
      <span className="text-3xl font-bold tracking-tight">{value}</span>
      <span className="text-sm text-muted-foreground font-mono">{unit}</span>
    </div>
  </motion.div>
);

export default function EngineeringMetrics() {
  return (
    <div className="max-w-7xl mx-auto py-12 space-y-12">
      <header className="space-y-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-mono uppercase tracking-widest"
        >
          <Activity size={12} />
          System Observability
        </motion.div>
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">Engineering Metrics</h1>
        <p className="text-xl text-muted-foreground max-w-3xl">
          Real-time performance benchmarks and operational telemetry for my deployed AI systems.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard title="Avg Inference Latency" value="482" unit="ms" icon={Zap} trend={-12} />
        <MetricCard title="Token Throughput" value="1.2k" unit="t/s" icon={Cpu} trend={8} />
        <MetricCard title="RAG Context Precision" value="94.2" unit="%" icon={Database} trend={2.4} />
        <MetricCard title="System Uptime" value="99.99" unit="%" icon={ShieldCheck} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Latency vs Throughput */}
        <div className="p-8 rounded-3xl border border-border bg-card/30 space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold flex items-center gap-2">
              <BarChart3 size={20} className="text-primary" />
              Model Benchmarks
            </h3>
            <span className="text-xs font-mono text-muted-foreground">Latency (ms) vs TPS</span>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={LATENCY_DATA}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="model" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'gray' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'gray' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#000', border: '1px solid #333', borderRadius: '12px' }}
                  cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                />
                <Bar dataKey="latency" fill="currentColor" className="text-primary" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Token Usage Over Time */}
        <div className="p-8 rounded-3xl border border-border bg-card/30 space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold flex items-center gap-2">
              <Activity size={20} className="text-primary" />
              Token Consumption
            </h3>
            <span className="text-xs font-mono text-muted-foreground">Monthly Volume</span>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={TOKEN_USAGE}>
                <defs>
                  <linearGradient id="colorPrompt" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--color-primary)" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="var(--color-primary)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'gray' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'gray' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#000', border: '1px solid #333', borderRadius: '12px' }}
                />
                <Area type="monotone" dataKey="prompt" stroke="currentColor" className="text-primary" fillOpacity={1} fill="url(#colorPrompt)" />
                <Area type="monotone" dataKey="completion" stroke="#666" fillOpacity={0} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 p-8 rounded-3xl border border-border bg-card/30 space-y-6">
          <h3 className="text-xl font-bold">RAG Evaluation Metrics (RAGAS)</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {RAG_PERFORMANCE.map((metric) => (
              <div key={metric.name} className="space-y-2">
                <div className="text-xs font-mono text-muted-foreground uppercase">{metric.name}</div>
                <div className="text-2xl font-bold">{metric.value}%</div>
                <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${metric.value}%` }}
                    transition={{ duration: 1, delay: 0.5 }}
                    className="h-full bg-primary"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="p-8 rounded-3xl border border-border bg-card/30 flex flex-col justify-center space-y-4">
          <h3 className="text-xl font-bold">Cost Optimization</h3>
          <p className="text-sm text-muted-foreground">
            Implementing semantic caching and prompt compression reduced monthly API costs by <span className="text-primary font-bold">42%</span> while maintaining accuracy.
          </p>
          <div className="pt-4 border-t border-border">
            <div className="flex justify-between text-xs font-mono mb-1">
              <span>Savings Target</span>
              <span>85%</span>
            </div>
            <div className="w-full h-2 bg-muted rounded-full">
              <div className="w-[85%] h-full bg-primary rounded-full" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
