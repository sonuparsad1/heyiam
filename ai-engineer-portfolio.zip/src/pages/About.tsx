import { motion } from "motion/react";
import { Card, CardContent } from "../components/ui/Card";
import { GraduationCap, Award, Zap, Code2, Cpu, Globe, Server, ShieldCheck, Workflow, User } from "lucide-react";

export default function About() {
  return (
    <div className="max-w-5xl mx-auto py-12 space-y-20">
      <header className="text-center space-y-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-mono font-bold uppercase tracking-widest"
        >
          <User size={14} />
          System_Architect_Profile
        </motion.div>
        <h1 className="text-5xl md:text-7xl font-extrabold tracking-tighter">Engineering the Future of AI.</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
          B.Tech Computer Science & Engineering student specializing in distributed AI systems, high-performance inference, and scalable machine learning infrastructure.
        </p>
      </header>

      <div className="grid md:grid-cols-2 gap-12 items-start">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="space-y-8"
        >
          <div className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-3 uppercase tracking-tight">
              <Workflow className="text-primary" size={24} /> 
              Engineering Philosophy
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                I approach AI not just as a collection of models, but as a complex engineering challenge. My focus lies at the intersection of <span className="text-foreground font-bold italic">Systems Programming</span> and <span className="text-foreground font-bold italic">Deep Learning</span>.
              </p>
              <p>
                I believe in building systems from the ground up—understanding the CUDA kernels, the memory management in KV-caches, and the distributed consensus protocols that make modern AI possible.
              </p>
              <p>
                My methodology is rooted in <span className="text-foreground font-bold">First Principles Thinking</span>: stripping away abstractions until the core logic is visible, then building back up with performance and scalability as primary constraints.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {[
              { label: "Core_Focus", val: "AI Infrastructure" },
              { label: "Methodology", val: "Systems-First" },
              { label: "Specialization", val: "LLM Optimization" },
              { label: "Current_Stack", val: "Rust / CUDA / PyTorch" },
            ].map((item) => (
              <div key={item.label} className="p-4 rounded-2xl bg-card/30 border border-border space-y-1">
                <div className="text-[10px] font-mono font-bold uppercase text-muted-foreground">{item.label}</div>
                <div className="text-sm font-bold">{item.val}</div>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="space-y-8"
        >
          <h2 className="text-2xl font-bold flex items-center gap-3 uppercase tracking-tight">
            <ShieldCheck className="text-primary" size={24} /> 
            Career Roadmap
          </h2>
          <Card className="bg-primary/5 border-primary/20 rounded-3xl overflow-hidden">
            <CardContent className="p-8 space-y-6">
              <div className="space-y-4">
                {[
                  { phase: "Phase 1: Foundations", status: "Completed", desc: "Mastering DSA, OS Internals, and Computer Architecture." },
                  { phase: "Phase 2: AI Systems", status: "In Progress", desc: "Deep dive into Transformer architectures and distributed inference." },
                  { phase: "Phase 3: Production Scale", status: "Upcoming", desc: "Building and deploying multi-node GPU clusters for real-time AI." },
                ].map((step, i) => (
                  <div key={i} className="relative pl-8 border-l border-primary/20 pb-6 last:pb-0">
                    <div className="absolute left-0 top-0 -translate-x-1/2 w-3 h-3 rounded-full bg-primary shadow-[0_0_10px_rgba(var(--primary),0.5)]" />
                    <div className="space-y-1">
                      <div className="flex justify-between items-center">
                        <h4 className="text-sm font-bold uppercase tracking-widest">{step.phase}</h4>
                        <span className="text-[10px] font-mono font-bold text-primary uppercase">{step.status}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">{step.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Technical Stack Grid */}
      <section className="space-y-8">
        <h2 className="text-2xl font-bold flex items-center gap-3 uppercase tracking-tight">
          <Cpu className="text-primary" size={24} /> 
          Technical_Substrate
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {[
            { name: "PyTorch", icon: Code2, level: "Advanced" },
            { name: "Rust", icon: Cpu, level: "Intermediate" },
            { name: "CUDA", icon: Zap, level: "Intermediate" },
            { name: "Docker", icon: Server, level: "Advanced" },
            { name: "Kubernetes", icon: Globe, level: "Intermediate" },
            { name: "React/TS", icon: Code2, level: "Advanced" },
          ].map((tech, i) => (
            <motion.div
              key={tech.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="group p-6 rounded-3xl bg-card/30 border border-border hover:border-primary/50 transition-all duration-500 text-center space-y-3"
            >
              <div className="p-3 bg-muted rounded-2xl inline-block group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                <tech.icon size={24} />
              </div>
              <div className="space-y-1">
                <div className="text-sm font-bold">{tech.name}</div>
                <div className="text-[10px] font-mono font-bold text-muted-foreground uppercase">{tech.level}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Education Timeline */}
      <section className="space-y-12">
        <h2 className="text-2xl font-bold flex items-center gap-3 uppercase tracking-tight">
          <GraduationCap className="text-primary" size={24} /> 
          Academic_History
        </h2>
        <div className="space-y-8">
          {[
            {
              year: "2025 - Present",
              title: "Bachelor of Technology (B.Tech)",
              institution: "Lovely Professional University",
              desc: "Specialization in Computer Science & Engineering. Researching efficient attention mechanisms and distributed training protocols.",
              metrics: ["GPA: 9.2/10.0", "Dean's List", "AI Research Lead"]
            }
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <Card className="bg-card/30 border-border overflow-hidden group">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary/0 group-hover:bg-primary transition-colors duration-500" />
                <CardContent className="p-8 flex flex-col md:flex-row gap-8 items-start">
                  <div className="space-y-2 shrink-0">
                    <div className="text-sm font-mono font-bold text-primary uppercase tracking-widest">{item.year}</div>
                    <div className="p-4 bg-muted rounded-2xl">
                      <Award size={32} className="text-primary" />
                    </div>
                  </div>
                  <div className="space-y-6 flex-1">
                    <div className="space-y-1">
                      <h3 className="text-2xl font-extrabold tracking-tight">{item.title}</h3>
                      <p className="text-lg font-bold text-muted-foreground">{item.institution}</p>
                    </div>
                    <p className="text-muted-foreground leading-relaxed max-w-3xl">
                      {item.desc}
                    </p>
                    <div className="flex flex-wrap gap-4">
                      {item.metrics.map((m) => (
                        <span key={m} className="text-[10px] font-mono font-bold px-3 py-1 bg-secondary rounded-full uppercase tracking-widest">
                          {m}
                        </span>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
