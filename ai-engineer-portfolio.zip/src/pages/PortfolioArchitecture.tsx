import { motion } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/Card";
import { Database, Cpu, ShieldCheck, Layers, Workflow } from "lucide-react";

const components = [
  {
    title: "Edge Inference Layer",
    icon: Cpu,
    desc: "Low-latency inference nodes deployed at the edge using custom quantization kernels (INT8/FP8) for real-time processing.",
    tech: ["TensorRT", "CUDA", "gRPC"]
  },
  {
    title: "Distributed Vector Substrate",
    icon: Database,
    desc: "Highly available vector database cluster with sub-10ms retrieval latency for RAG operations and semantic search.",
    tech: ["Pinecone", "Milvus", "Redis"]
  },
  {
    title: "Orchestration Engine",
    icon: Workflow,
    desc: "Dynamic GPU resource allocation and task scheduling across heterogeneous compute clusters.",
    tech: ["Kubernetes", "Ray", "Slurm"]
  },
  {
    title: "Security & Guardrails",
    icon: ShieldCheck,
    desc: "Multi-layer prompt injection detection and response filtering to ensure safe and compliant AI interactions.",
    tech: ["LlamaGuard", "Custom RegEx", "PII Masking"]
  }
];

export default function PortfolioArchitecture() {
  return (
    <div className="max-w-6xl mx-auto py-12 space-y-20">
      <header className="text-center space-y-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-mono font-bold uppercase tracking-widest"
        >
          <Layers size={14} />
          System_Architecture_Blueprint
        </motion.div>
        <h1 className="text-5xl md:text-7xl font-extrabold tracking-tighter">Architecture Transparency.</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
          A deep dive into the technical substrate powering my AI systems, from edge inference to distributed orchestration.
        </p>
      </header>

      {/* Visual Diagram Placeholder */}
      <section className="relative aspect-video bg-card/30 border border-border rounded-[40px] overflow-hidden group">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="grid grid-cols-3 gap-12 p-12 w-full max-w-4xl opacity-50 group-hover:opacity-100 transition-opacity duration-700">
            {/* Mock Diagram Elements */}
            <div className="space-y-8">
              <div className="h-24 w-full bg-muted rounded-2xl border border-primary/20 flex items-center justify-center font-mono text-[10px] font-bold uppercase tracking-widest">User_Request</div>
              <div className="h-24 w-full bg-muted rounded-2xl border border-primary/20 flex items-center justify-center font-mono text-[10px] font-bold uppercase tracking-widest">API_Gateway</div>
            </div>
            <div className="space-y-8 pt-12">
              <div className="h-48 w-full bg-primary/10 rounded-3xl border-2 border-primary/40 flex items-center justify-center font-mono text-xs font-bold uppercase tracking-widest text-primary text-center p-4">Inference_Engine<br/>(Heterogeneous_Cluster)</div>
            </div>
            <div className="space-y-8">
              <div className="h-24 w-full bg-muted rounded-2xl border border-primary/20 flex items-center justify-center font-mono text-[10px] font-bold uppercase tracking-widest">Vector_Store</div>
              <div className="h-24 w-full bg-muted rounded-2xl border border-primary/20 flex items-center justify-center font-mono text-[10px] font-bold uppercase tracking-widest">Knowledge_Graph</div>
            </div>
          </div>
        </div>
        <div className="absolute bottom-8 left-8 right-8 flex justify-between items-end">
          <div className="space-y-1">
            <div className="text-[10px] font-mono font-bold uppercase text-muted-foreground">System_Status</div>
            <div className="flex items-center gap-2 text-primary font-bold text-xs">
              <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
              OPERATIONAL_NOMINAL
            </div>
          </div>
          <div className="text-[10px] font-mono font-bold uppercase text-muted-foreground tracking-widest">v4.2.0_STABLE</div>
        </div>
      </section>

      <div className="grid md:grid-cols-2 gap-8">
        {components.map((comp, i) => (
          <motion.div
            key={comp.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="h-full bg-card/30 border-border group hover:border-primary/50 transition-all duration-500">
              <CardHeader className="flex flex-row items-center gap-4">
                <div className="p-3 bg-muted rounded-2xl group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  <comp.icon size={24} />
                </div>
                <CardTitle className="text-xl font-bold tracking-tight">{comp.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {comp.desc}
                </p>
                <div className="flex flex-wrap gap-2">
                  {comp.tech.map((t) => (
                    <span key={t} className="text-[10px] font-mono font-bold px-2 py-0.5 bg-secondary rounded-md uppercase tracking-widest">
                      {t}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <section className="bg-primary/5 border border-primary/20 rounded-[40px] p-12 space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2">
            <h2 className="text-3xl font-extrabold tracking-tight">Scalability & Resilience</h2>
            <p className="text-muted-foreground">How the system handles 100k+ concurrent requests.</p>
          </div>
          <div className="flex gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold">99.99%</div>
              <div className="text-[10px] font-mono font-bold uppercase text-muted-foreground">Uptime</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">&lt;50ms</div>
              <div className="text-[10px] font-mono font-bold uppercase text-muted-foreground">Latency</div>
            </div>
          </div>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { title: "Horizontal Scaling", desc: "Auto-scaling groups triggered by GPU utilization and request queue depth." },
            { title: "Fault Tolerance", desc: "Multi-region deployment with automated failover and state synchronization." },
            { title: "Load Balancing", desc: "Layer 7 load balancing with session affinity and health-aware routing." },
          ].map((item) => (
            <div key={item.title} className="space-y-2">
              <h4 className="font-bold text-sm uppercase tracking-widest">{item.title}</h4>
              <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
