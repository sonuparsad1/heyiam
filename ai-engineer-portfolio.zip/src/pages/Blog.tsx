import { useState, useMemo, useCallback } from "react";
import { motion } from "motion/react";
import { List } from "react-window";
import Fuse from "fuse.js";
import { Card, CardContent } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Calendar, Clock, ArrowRight, Search, Filter, Tag as TagIcon } from "lucide-react";
import { Link } from "react-router-dom";

const posts = Array.from({ length: 100 }, (_, i) => ({
  id: i + 1,
  title: i % 3 === 0 ? "Understanding Transformers in NLP" : i % 3 === 1 ? "Building Scalable React Apps with Vite" : "Deploying ML Models to Production",
  excerpt: "A deep dive into the architecture that revolutionized natural language processing, from self-attention mechanisms to positional encoding.",
  date: "Oct 15, 2024",
  readTime: `${5 + (i % 10)} min read`,
  tags: ["AI", "NLP", "Deep Learning", "Engineering", "MLOps"].slice(i % 3, (i % 3) + 3),
  category: ["AI Research", "Engineering", "MLOps"][i % 3],
  slug: `post-${i + 1}`
}));

const categories = ["All", "AI Research", "Engineering", "MLOps"];

const fuseOptions = {
  keys: ["title", "excerpt", "tags", "category"],
  threshold: 0.3,
};

export default function Blog() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const fuse = useMemo(() => new Fuse(posts, fuseOptions), []);

  const filteredPosts = useMemo(() => {
    let results = searchQuery 
      ? fuse.search(searchQuery).map(r => r.item)
      : posts;
    
    if (activeCategory !== "All") {
      results = results.filter(p => p.category === activeCategory);
    }
    
    return results;
  }, [searchQuery, activeCategory, fuse]);

  const Row = useCallback(({ index, style }: any) => {
    const post = filteredPosts[index];
    if (!post) return null;

    return (
      <div style={style} className="px-1 py-3">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="group hover:border-primary/50 transition-all duration-300 overflow-hidden relative bg-card/30">
            <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary/0 group-hover:bg-primary transition-colors duration-300" />
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-3">
                <div className="flex flex-wrap gap-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-primary/10 text-primary rounded-md uppercase tracking-widest">
                    {post.category}
                  </span>
                  {post.tags.map((tag) => (
                    <span key={tag} className="text-[10px] font-mono px-2 py-0.5 bg-muted text-muted-foreground rounded-md uppercase">
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="flex items-center gap-4 text-[10px] text-muted-foreground font-mono uppercase">
                  <span className="flex items-center gap-1"><Calendar size={12} /> {post.date}</span>
                  <span className="flex items-center gap-1"><Clock size={12} /> {post.readTime}</span>
                </div>
              </div>
              <h2 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                {post.title}
              </h2>
              <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                {post.excerpt}
              </p>
              <Button asChild variant="ghost" className="p-0 h-auto gap-2 text-primary hover:text-primary/80 hover:bg-transparent group/btn text-xs font-bold uppercase tracking-widest">
                <Link to={`/blog/${post.slug}`}>
                  Read Article <ArrowRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }, [filteredPosts]);

  return (
    <div className="max-w-5xl mx-auto space-y-12 py-12">
      <header className="space-y-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-mono uppercase tracking-widest"
        >
          <TagIcon size={12} />
          Technical Publications
        </motion.div>
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">Engineering Blog</h1>
        <p className="text-xl text-muted-foreground max-w-2xl">
          Deep dives into AI architectures, system design, and production engineering.
        </p>
      </header>

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-card/30 p-4 rounded-2xl border border-border">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Fuzzy search articles, tags..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-background/50 pl-10 pr-4 py-2 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none transition-all"
          />
        </div>
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 hide-scrollbar">
          <Filter className="h-4 w-4 text-muted-foreground mr-2 shrink-0" />
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${
                activeCategory === category 
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" 
                  : "bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground"
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      <div className="h-[800px] w-full">
        {filteredPosts.length > 0 ? (
          <List
            style={{ height: 800 }}
            rowCount={filteredPosts.length}
            rowHeight={220}
            rowComponent={Row}
            rowProps={{}}
            className="hide-scrollbar"
          />
        ) : (
          <div className="text-center py-20 text-muted-foreground space-y-4">
            <p className="text-lg font-mono">NO_RESULTS_FOUND</p>
            <Button 
              variant="outline" 
              onClick={() => { setSearchQuery(""); setActiveCategory("All"); }}
              className="rounded-full"
            >
              Reset Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
