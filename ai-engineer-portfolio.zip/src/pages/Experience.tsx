import { motion } from "motion/react";
import { Card, CardContent } from "../components/ui/Card";
import { Briefcase, Calendar, MapPin, TrendingUp, GitBranch } from "lucide-react";

const experiences = [
  {
    id: 1,
    role: "Machine Learning Intern",
    company: "TechCorp AI",
    location: "San Francisco, CA (Remote)",
    date: "May 2024 - Aug 2024",
    impact: [
      { label: "Accuracy Increase", value: "+15%" },
      { label: "Training Time", value: "-30%" }
    ],
    description: [
      "Developed a predictive maintenance model using Random Forest, improving fault detection accuracy by 15%.",
      "Optimized data preprocessing pipelines in Python, reducing model training time by 30%.",
      "Collaborated with the backend team to deploy the model as a REST API using FastAPI.",
    ],
    decisions: "Chose FastAPI over Flask for asynchronous request handling, significantly improving inference throughput under load."
  },
  {
    id: 2,
    role: "Software Engineering Intern",
    company: "InnovateTech",
    location: "New York, NY",
    date: "Jun 2023 - Aug 2023",
    impact: [
      { label: "Test Coverage", value: "85%" },
      { label: "Load Time", value: "-40%" }
    ],
    description: [
      "Built a full-stack internal dashboard using React and Node.js to visualize real-time server metrics.",
      "Implemented JWT authentication and role-based access control.",
      "Wrote unit tests using Jest, achieving 85% code coverage.",
    ],
    decisions: "Implemented React.memo and useMemo for the real-time charts to prevent unnecessary re-renders during high-frequency data updates."
  },
  {
    id: 3,
    role: "Open Source Contributor",
    company: "Various Projects",
    location: "Global",
    date: "Jan 2023 - Present",
    impact: [
      { label: "PRs Merged", value: "20+" },
      { label: "Stars Gained", value: "500+" }
    ],
    description: [
      "Contributed to popular open-source AI libraries by fixing bugs and improving documentation.",
      "Developed a widely-used React component library for data visualization.",
    ],
    decisions: "Adopted a strict semantic versioning and conventional commits workflow to streamline the release process for the community."
  },
];

export default function Experience() {
  return (
    <div className="max-w-5xl mx-auto space-y-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Experience</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          My professional journey, focusing on measurable impact and engineering decisions.
        </p>
      </motion.div>

      <div className="space-y-12 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-border">
        {experiences.map((exp, i) => (
          <motion.div
            key={exp.id}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.5, delay: i * 0.1 }}
            className="relative flex flex-col md:flex-row items-center justify-between md:odd:flex-row-reverse group"
          >
            {/* Timeline Node */}
            <div className="absolute left-5 md:left-1/2 -translate-x-1/2 flex items-center justify-center w-10 h-10 rounded-full border-4 border-background bg-primary text-primary-foreground shadow-lg z-10 group-hover:scale-110 transition-transform duration-300">
              <Briefcase className="h-4 w-4" />
            </div>

            {/* Content Card */}
            <Card className="w-[calc(100%-3rem)] ml-12 md:ml-0 md:w-[calc(50%-2.5rem)] hover:border-primary/30 transition-colors duration-300 shadow-sm hover:shadow-md">
              <CardContent className="p-6 sm:p-8 space-y-6">
                
                {/* Header */}
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold tracking-tight group-hover:text-primary transition-colors">{exp.role}</h3>
                  <div className="text-lg font-medium text-muted-foreground">{exp.company}</div>
                  <div className="flex flex-wrap gap-4 text-sm text-muted-foreground pt-2">
                    <div className="flex items-center gap-1.5 bg-muted/50 px-2.5 py-1 rounded-md">
                      <Calendar className="h-4 w-4" /> {exp.date}
                    </div>
                    <div className="flex items-center gap-1.5 bg-muted/50 px-2.5 py-1 rounded-md">
                      <MapPin className="h-4 w-4" /> {exp.location}
                    </div>
                  </div>
                </div>

                {/* Impact Metrics */}
                <div className="grid grid-cols-2 gap-4 py-4 border-y border-border/50">
                  {exp.impact.map((metric, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold flex items-center gap-1.5">
                        <TrendingUp className="h-3 w-3 text-primary" /> {metric.label}
                      </div>
                      <div className="text-2xl font-bold text-foreground">{metric.value}</div>
                    </div>
                  ))}
                </div>

                {/* Description */}
                <ul className="space-y-3 text-muted-foreground">
                  {exp.description.map((desc, j) => (
                    <li key={j} className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary/50 mt-2 shrink-0" />
                      <span className="leading-relaxed">{desc}</span>
                    </li>
                  ))}
                </ul>

                {/* Engineering Decisions */}
                <div className="pt-4 bg-primary/5 rounded-xl p-4 border border-primary/10">
                  <div className="flex items-center gap-2 text-sm font-semibold text-primary mb-2">
                    <GitBranch className="h-4 w-4" /> Engineering Decision
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {exp.decisions}
                  </p>
                </div>

              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
