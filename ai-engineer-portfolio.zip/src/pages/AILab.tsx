import { useState, useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/Card";
import { 
  Scatter, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Line,
  ComposedChart,
  ZAxis
} from "recharts";
import { Calculator, BrainCircuit, Terminal, Activity, Zap } from "lucide-react";
import { Button } from "../components/ui/Button";
import { AILabChat } from "../features/ailab/AILabChat";

export default function AILab() {
  const [activeTab, setActiveTab] = useState<'inference' | 'regression'>('inference');
  const [modelType, setModelType] = useState<'linear' | 'logistic'>('linear');
  
  // Linear Regression State
  const [slope, setSlope] = useState(2.5);
  const [intercept, setIntercept] = useState(5);
  const [linearData, setLinearData] = useState<{x: number, y: number}[]>([]);

  // Logistic Regression State
  const [w1, setW1] = useState(0.5);
  const [w2, setW2] = useState(0.5);
  const [b, setB] = useState(0);
  const [logisticData, setLogisticData] = useState<{x1: number, x2: number, label: number}[]>([]);

  useEffect(() => {
    generateLinearData();
    generateLogisticData();
  }, []);

  const generateLinearData = () => {
    const newData = Array.from({ length: 50 }, () => {
      const x = Math.random() * 20;
      const trueSlope = 2.5;
      const trueIntercept = 5;
      const noise = (Math.random() - 0.5) * 10;
      const y = trueSlope * x + trueIntercept + noise;
      return { x, y };
    });
    setLinearData(newData);
  };

  const generateLogisticData = () => {
    const newData = Array.from({ length: 60 }, () => {
      const x1 = Math.random() * 20 - 10;
      const x2 = Math.random() * 20 - 10;
      const label = (x1 - x2 + 2 > 0) ? 1 : 0;
      const noise = Math.random() > 0.95 ? (label === 1 ? 0 : 1) : label;
      return { x1, x2, label: noise };
    });
    setLogisticData(newData);
  };

  const mse = useMemo(() => {
    if (linearData.length === 0) return 0;
    let error = 0;
    linearData.forEach(point => {
      const predicted = slope * point.x + intercept;
      error += Math.pow(predicted - point.y, 2);
    });
    return error / linearData.length;
  }, [slope, intercept, linearData]);

  const accuracy = useMemo(() => {
    if (logisticData.length === 0) return 0;
    let correct = 0;
    logisticData.forEach(point => {
      const z = w1 * point.x1 + w2 * point.x2 + b;
      const predicted = z >= 0 ? 1 : 0;
      if (predicted === point.label) correct++;
    });
    return (correct / logisticData.length) * 100;
  }, [w1, w2, b, logisticData]);

  const linearLineData = useMemo(() => [
    { x: 0, y: intercept },
    { x: 20, y: slope * 20 + intercept }
  ], [slope, intercept]);

  const logisticBoundaryData = useMemo(() => {
    const xMin = -12, xMax = 12;
    const yMin = -12, yMax = 12;
    
    if (Math.abs(w2) < 0.01) {
      if (Math.abs(w1) < 0.01) return [];
      const x1 = -b / w1;
      return [
        { x1, x2: yMin },
        { x1, x2: yMax }
      ];
    }

    if (Math.abs(w2) >= Math.abs(w1)) {
      return [
        { x1: xMin, x2: -(w1 * xMin + b) / w2 },
        { x1: xMax, x2: -(w1 * xMax + b) / w2 }
      ];
    } else {
      return [
        { x1: -(w2 * yMin + b) / w1, x2: yMin },
        { x1: -(w2 * yMax + b) / w1, x2: yMax }
      ];
    }
  }, [w1, w2, b]);

  const logisticClass0 = logisticData.filter(d => d.label === 0);
  const logisticClass1 = logisticData.filter(d => d.label === 1);

  const autoFitLinear = () => {
    const n = linearData.length;
    if (n === 0) return;
    
    let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
    linearData.forEach(p => {
      sumX += p.x;
      sumY += p.y;
      sumXY += p.x * p.y;
      sumXX += p.x * p.x;
    });

    const newSlope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    const newIntercept = (sumY - newSlope * sumX) / n;

    setSlope(parseFloat(newSlope.toFixed(2)));
    setIntercept(parseFloat(newIntercept.toFixed(2)));
  };

  return (
    <div className="max-w-7xl mx-auto py-12 space-y-12">
      <header className="space-y-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-mono uppercase tracking-widest"
        >
          <BrainCircuit size={12} />
          Experimental Sandbox
        </motion.div>
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">AI Lab</h1>
        <p className="text-xl text-muted-foreground max-w-3xl">
          Interactive machine learning playground. Visualize algorithms and test inference engines in real-time.
        </p>
      </header>

      <div className="flex flex-wrap gap-4 p-1 rounded-2xl bg-muted/30 border border-border w-fit">
        <button 
          onClick={() => setActiveTab('inference')}
          className={`flex items-center gap-2 px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'inference' ? 'bg-background text-primary shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
        >
          <Terminal size={16} /> Inference Engine
        </button>
        <button 
          onClick={() => setActiveTab('regression')}
          className={`flex items-center gap-2 px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'regression' ? 'bg-background text-primary shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
        >
          <Activity size={16} /> Algorithm Visualizer
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'inference' ? (
          <motion.div
            key="inference"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-8"
          >
            <div className="lg:col-span-2">
              <AILabChat />
            </div>
            <div className="space-y-6">
              <Card className="bg-card/30 border-border">
                <CardHeader>
                  <CardTitle className="text-sm font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                    <Terminal size={14} /> System Config
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-1">
                    <div className="text-[10px] font-mono text-muted-foreground uppercase">Model</div>
                    <div className="text-sm font-bold">Gemini 3 Flash (Experimental)</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-[10px] font-mono text-muted-foreground uppercase">Quantization</div>
                    <div className="text-sm font-bold">INT8 (Simulated)</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-[10px] font-mono text-muted-foreground uppercase">Context Window</div>
                    <div className="text-sm font-bold">1M Tokens</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card/30 border-border">
                <CardHeader>
                  <CardTitle className="text-sm font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                    <Zap size={14} /> Hardware Specs
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-1">
                    <div className="text-[10px] font-mono text-muted-foreground uppercase">GPU Cluster</div>
                    <div className="text-sm font-bold">8x NVIDIA H100 (SXM5)</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-[10px] font-mono text-muted-foreground uppercase">Interconnect</div>
                    <div className="text-sm font-bold">NVLink 900GB/s</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-[10px] font-mono text-muted-foreground uppercase">Memory</div>
                    <div className="text-sm font-bold">640GB HBM3</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="regression"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <div className="flex justify-center gap-4">
              <button 
                onClick={() => setModelType('linear')}
                className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${modelType === 'linear' ? 'bg-primary text-primary-foreground' : 'bg-muted hover:bg-muted/80'}`}
              >
                Linear Regression
              </button>
              <button 
                onClick={() => setModelType('logistic')}
                className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${modelType === 'logistic' ? 'bg-primary text-primary-foreground' : 'bg-muted hover:bg-muted/80'}`}
              >
                Logistic Regression
              </button>
            </div>

            {modelType === 'linear' ? (
              <div className="grid lg:grid-cols-3 gap-8">
                <Card className="lg:col-span-1 bg-card/30">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-sm uppercase tracking-widest">
                      <Calculator className="h-4 w-4 text-primary" /> Controls
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-xs font-mono text-muted-foreground uppercase">Slope (m): {slope.toFixed(2)}</label>
                        <input type="range" min="-5" max="10" step="0.1" value={slope} onChange={(e) => setSlope(Number(e.target.value))} className="w-full accent-primary" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-mono text-muted-foreground uppercase">Intercept (c): {intercept.toFixed(2)}</label>
                        <input type="range" min="-20" max="50" step="0.5" value={intercept} onChange={(e) => setIntercept(Number(e.target.value))} className="w-full accent-primary" />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <Button onClick={autoFitLinear} className="w-full" variant="outline">Auto-Fit (OLS)</Button>
                      <Button onClick={generateLinearData} className="w-full" variant="outline">Regenerate Data</Button>
                    </div>
                    <div className="p-4 bg-muted/50 rounded-xl border border-border/50">
                      <div className="text-[10px] font-mono text-muted-foreground uppercase mb-1">Loss (MSE)</div>
                      <div className="text-2xl font-bold text-foreground">{mse.toFixed(2)}</div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="lg:col-span-2 bg-card/30 min-h-[400px]">
                  <CardContent className="h-[450px] pt-6">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart margin={{ top: 20, right: 20, bottom: 20, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} />
                        <XAxis type="number" dataKey="x" domain={[0, 20]} stroke="gray" tick={{ fontSize: 10 }} />
                        <YAxis type="number" dataKey="y" domain={[-10, 70]} stroke="gray" tick={{ fontSize: 10 }} />
                        <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333', borderRadius: '12px' }} />
                        <Scatter name="Data" data={linearData} fill="var(--color-primary)" opacity={0.6} isAnimationActive={false} />
                        <Line data={linearLineData} type="linear" dataKey="y" stroke="var(--color-primary)" strokeWidth={3} dot={false} isAnimationActive={false} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <div className="grid lg:grid-cols-3 gap-8">
                <Card className="lg:col-span-1 bg-card/30">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-sm uppercase tracking-widest">
                      <Calculator className="h-4 w-4 text-primary" /> Parameters
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-xs font-mono text-muted-foreground uppercase">w1: {w1.toFixed(2)}</label>
                        <input type="range" min="-5" max="5" step="0.1" value={w1} onChange={(e) => setW1(Number(e.target.value))} className="w-full accent-primary" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-mono text-muted-foreground uppercase">w2: {w2.toFixed(2)}</label>
                        <input type="range" min="-5" max="5" step="0.1" value={w2} onChange={(e) => setW2(Number(e.target.value))} className="w-full accent-primary" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-mono text-muted-foreground uppercase">Bias: {b.toFixed(2)}</label>
                        <input type="range" min="-10" max="10" step="0.5" value={b} onChange={(e) => setB(Number(e.target.value))} className="w-full accent-primary" />
                      </div>
                    </div>
                    <Button onClick={generateLogisticData} className="w-full" variant="outline">Regenerate Data</Button>
                    <div className="p-4 bg-muted/50 rounded-xl border border-border/50">
                      <div className="text-[10px] font-mono text-muted-foreground uppercase mb-1">Accuracy</div>
                      <div className="text-2xl font-bold text-foreground">{accuracy.toFixed(1)}%</div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="lg:col-span-2 bg-card/30 min-h-[400px]">
                  <CardContent className="h-[450px] pt-6">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart margin={{ top: 20, right: 20, bottom: 20, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} />
                        <XAxis type="number" dataKey="x1" domain={[-12, 12]} stroke="gray" tick={{ fontSize: 10 }} />
                        <YAxis type="number" dataKey="x2" domain={[-12, 12]} stroke="gray" tick={{ fontSize: 10 }} />
                        <ZAxis type="number" range={[40, 40]} />
                        <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333', borderRadius: '12px' }} />
                        <Scatter name="Class 0" data={logisticClass0} fill="var(--color-foreground)" opacity={0.4} isAnimationActive={false} />
                        <Scatter name="Class 1" data={logisticClass1} fill="var(--color-foreground)" opacity={0.8} isAnimationActive={false} />
                        {Math.abs(w2) > 0.1 && (
                          <Line data={logisticBoundaryData} type="linear" dataKey="x2" stroke="currentColor" strokeWidth={2} strokeDasharray="5 5" dot={false} isAnimationActive={false} />
                        )}
                      </ComposedChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
