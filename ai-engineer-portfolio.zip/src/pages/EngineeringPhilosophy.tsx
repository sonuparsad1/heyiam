import { motion } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/Card";
import { BrainCircuit, Network, ShieldCheck, Zap, ServerCog, GitMerge } from "lucide-react";

const philosophies = [
  {
    icon: <ServerCog className="h-6 w-6 text-primary" />,
    title: "Systems Over Scripts",
    description: "I believe in building robust, scalable AI architectures rather than fragile Jupyter notebooks. Production ML requires rigorous software engineering practices, CI/CD for models, and monitoring for data drift."
  },
  {
    icon: <Zap className="h-6 w-6 text-primary" />,
    title: "Performance & Optimization",
    description: "An AI model is only as good as its inference speed and cost. I focus on quantization, model pruning, and efficient serving using tools like ONNX, TensorRT, and vLLM to maximize throughput."
  },
  {
    icon: <ShieldCheck className="h-6 w-6 text-primary" />,
    title: "Responsible AI & Security",
    description: "Security isn't an afterthought. I design systems with prompt injection defenses, strict output validation, and PII redaction. AI should be transparent, fair, and secure by design."
  },
  {
    icon: <Network className="h-6 w-6 text-primary" />,
    title: "Modular Architecture",
    description: "Decoupling the AI engine from the application logic is crucial. I advocate for microservices architectures where models are served via gRPC or REST APIs, allowing independent scaling and updates."
  },
  {
    icon: <BrainCircuit className="h-6 w-6 text-primary" />,
    title: "Continuous Learning",
    description: "The AI landscape shifts weekly. My approach is to master the fundamentals (Linear Algebra, Calculus, Statistics) while staying adaptable to new architectures like Transformers, Mamba, or whatever comes next."
  },
  {
    icon: <GitMerge className="h-6 w-6 text-primary" />,
    title: "Data-Centric AI",
    description: "Better data beats a better algorithm. I prioritize building robust data pipelines, ensuring high-quality annotations, and implementing active learning loops to continuously improve model performance."
  }
];

export default function EngineeringPhilosophy() {
  return (
    <div className="space-y-12 max-w-5xl mx-auto">
      <div className="text-center space-y-4">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold tracking-tight"
        >
          AI Engineering Philosophy
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-lg text-muted-foreground max-w-2xl mx-auto"
        >
          My approach to designing, building, and scaling intelligent systems for production environments.
        </motion.p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {philosophies.map((item, index) => (
          <motion.div
            key={item.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 + 0.2 }}
          >
            <Card className="h-full hover:border-primary/50 transition-colors duration-300">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  {item.icon}
                </div>
                <CardTitle className="text-xl">{item.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  {item.description}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="mt-16 p-8 bg-muted rounded-2xl border border-border"
      >
        <h2 className="text-2xl font-bold mb-4">Current Research Interests</h2>
        <ul className="space-y-3 text-muted-foreground">
          <li className="flex items-center gap-2">
            <div className="h-1.5 w-1.5 rounded-full bg-primary" />
            Parameter-Efficient Fine-Tuning (PEFT) techniques like LoRA and QLoRA.
          </li>
          <li className="flex items-center gap-2">
            <div className="h-1.5 w-1.5 rounded-full bg-primary" />
            Retrieval-Augmented Generation (RAG) optimization and vector database scaling.
          </li>
          <li className="flex items-center gap-2">
            <div className="h-1.5 w-1.5 rounded-full bg-primary" />
            Agentic workflows and multi-agent system orchestration.
          </li>
          <li className="flex items-center gap-2">
            <div className="h-1.5 w-1.5 rounded-full bg-primary" />
            Edge AI and deploying quantized models on resource-constrained devices.
          </li>
        </ul>
      </motion.div>
    </div>
  );
}
