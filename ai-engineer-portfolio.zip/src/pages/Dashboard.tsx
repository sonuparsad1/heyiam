import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { 
  Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer,
  XAxis, YAxis, CartesianGrid, Tooltip,
  AreaChart, Area
} from "recharts";
import { Activity, BookOpen, GitCommit, Target, Save, Edit3, Globe, Server, Code2, Zap } from "lucide-react";

const skillData = [
  { subject: 'Machine Learning', A: 95, fullMark: 100 },
  { subject: 'Deep Learning', A: 90, fullMark: 100 },
  { subject: 'System Design', A: 85, fullMark: 100 },
  { subject: 'Backend Dev', A: 80, fullMark: 100 },
  { subject: 'Frontend Dev', A: 75, fullMark: 100 },
  { subject: 'MLOps', A: 88, fullMark: 100 },
];

const inferenceLatency = [
  { time: '00:00', latency: 42 },
  { time: '04:00', latency: 38 },
  { time: '08:00', latency: 45 },
  { time: '12:00', latency: 52 },
  { time: '16:00', latency: 48 },
  { time: '20:00', latency: 41 },
  { time: '23:59', latency: 39 },
];

const systemHealth = [
  { name: 'API Gateway', status: 'Healthy', load: 24 },
  { name: 'Inference Node A', status: 'Healthy', load: 68 },
  { name: 'Inference Node B', status: 'Warning', load: 92 },
  { name: 'Vector DB', status: 'Healthy', load: 12 },
];

export default function Dashboard() {
  const [isEditing, setIsEditing] = useState(false);
  const [portfolio, setPortfolio] = useState<any>(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetch("/api/portfolio")
      .then(res => res.json())
      .then(data => setPortfolio(data));
  }, []);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const response = await fetch("/api/portfolio", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(portfolio)
      });
      if (response.ok) {
        setIsEditing(false);
      }
    } catch (e) {
      console.error("Failed to save portfolio", e);
    } finally {
      setIsSaving(false);
    }
  };

  if (!portfolio) return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="text-center space-y-4">
        <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Initializing_System_Metrics...</p>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto py-12 space-y-12">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div className="space-y-4">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-mono uppercase tracking-widest"
          >
            <Activity size={12} />
            Live System Analytics
          </motion.div>
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">Engineering Hub</h1>
          <p className="text-xl text-muted-foreground max-w-2xl">
            Real-time telemetry from my production systems, research progress, and core competencies.
          </p>
        </div>
        <Button 
          variant={isEditing ? "default" : "outline"} 
          className="gap-2 rounded-full font-bold uppercase tracking-widest text-xs h-12 px-8"
          onClick={() => isEditing ? handleSave() : setIsEditing(true)}
          disabled={isSaving}
        >
          {isEditing ? (
            <><Save size={16} /> {isSaving ? 'SYNCING...' : 'COMMIT_CHANGES'}</>
          ) : (
            <><Edit3 size={16} /> EDIT_PROFILE</>
          )}
        </Button>
      </header>

      {isEditing && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card/30 border border-primary/20 rounded-3xl p-8"
        >
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Identity_Label</label>
                <input 
                  className="w-full bg-background/50 border border-border rounded-xl p-3 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                  value={portfolio.name}
                  onChange={e => setPortfolio({...portfolio, name: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Designation_String</label>
                <input 
                  className="w-full bg-background/50 border border-border rounded-xl p-3 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                  value={portfolio.role}
                  onChange={e => setPortfolio({...portfolio, role: e.target.value})}
                />
              </div>
            </div>
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Communication_Endpoint</label>
                <input 
                  className="w-full bg-background/50 border border-border rounded-xl p-3 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                  value={portfolio.contact.email}
                  onChange={e => setPortfolio({
                    ...portfolio, 
                    contact: { ...portfolio.contact, email: e.target.value }
                  })}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Mission_Manifesto</label>
                <textarea 
                  className="w-full bg-background/50 border border-border rounded-xl p-3 text-sm h-24 focus:ring-2 focus:ring-primary/20 outline-none transition-all resize-none"
                  value={portfolio.careerObjective}
                  onChange={e => setPortfolio({...portfolio, careerObjective: e.target.value})}
                />
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { title: "ALGO_SOLVED", value: "350+", icon: Code2, trend: "+12_WEEKLY", color: "text-primary" },
          { title: "PAPERS_INDEXED", value: "42", icon: BookOpen, trend: "LATEST: ATTENTION", color: "text-primary" },
          { title: "GIT_COMMITS", value: "1,204", icon: GitCommit, trend: "TOP_5%_GLOBAL", color: "text-primary" },
          { title: "SYSTEM_UPTIME", value: "99.99%", icon: Server, trend: "STABLE_24H", color: "text-primary" },
        ].map((kpi, i) => (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="bg-card/30 border-border group hover:border-primary/50 transition-all duration-500">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="p-2 bg-muted rounded-lg group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <kpi.icon size={20} />
                  </div>
                  <div className="text-[10px] font-mono font-bold text-muted-foreground uppercase tracking-widest">{kpi.title}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-3xl font-extrabold tracking-tighter">{kpi.value}</div>
                  <div className={`text-[10px] font-mono font-bold uppercase ${kpi.color}`}>{kpi.trend}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Competency Radar */}
        <Card className="lg:col-span-1 bg-card/30 border-border">
          <CardHeader>
            <CardTitle className="text-sm font-bold uppercase tracking-widest flex items-center gap-2">
              <Target size={16} className="text-primary" />
              Competency_Radar
            </CardTitle>
          </CardHeader>
          <CardContent className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={skillData}>
                <PolarGrid stroke="var(--border)" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: 'var(--muted-foreground)', fontSize: 10, fontWeight: 'bold' }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                <Radar name="Skills" dataKey="A" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.2} />
                <Tooltip contentStyle={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', borderRadius: '12px', fontSize: '12px' }} />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Inference Latency */}
        <Card className="lg:col-span-2 bg-card/30 border-border">
          <CardHeader>
            <CardTitle className="text-sm font-bold uppercase tracking-widest flex items-center gap-2">
              <Zap size={16} className="text-primary" />
              Inference_Latency_MS
            </CardTitle>
          </CardHeader>
          <CardContent className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={inferenceLatency}>
                <defs>
                  <linearGradient id="colorLatency" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="time" stroke="var(--muted-foreground)" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis stroke="var(--muted-foreground)" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', borderRadius: '12px' }}
                  itemStyle={{ color: 'hsl(var(--primary))', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="latency" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorLatency)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* System Health Status */}
        <Card className="lg:col-span-3 bg-card/30 border-border">
          <CardHeader>
            <CardTitle className="text-sm font-bold uppercase tracking-widest flex items-center gap-2">
              <Globe size={16} className="text-primary" />
              Distributed_System_Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {systemHealth.map((node) => (
                <div key={node.name} className="p-4 rounded-2xl bg-background/50 border border-border space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <div className="text-xs font-bold">{node.name}</div>
                      <div className={`text-[10px] font-mono font-bold uppercase ${node.status === 'Healthy' ? 'text-primary' : 'text-muted-foreground'}`}>
                        {node.status}
                      </div>
                    </div>
                    <div className={`h-2 w-2 rounded-full animate-pulse ${node.status === 'Healthy' ? 'bg-primary' : 'bg-muted-foreground'}`} />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] font-mono text-muted-foreground">
                      <span>LOAD</span>
                      <span>{node.load}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${node.load}%` }}
                        className={`h-full rounded-full ${node.load > 80 ? 'bg-muted-foreground' : 'bg-primary'}`}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
