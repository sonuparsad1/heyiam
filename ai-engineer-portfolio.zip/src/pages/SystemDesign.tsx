import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Layout, Server, Shield, Zap, Users, Cpu, Share2, ChevronRight, Info } from 'lucide-react';

const CASE_STUDIES = [
  {
    id: '1',
    title: 'Scaling LLM Inference to 10M Users',
    icon: Users,
    description: 'Architecture for handling massive concurrent inference requests with low latency and high availability.',
    challenges: [
      'Token generation latency',
      'GPU resource allocation',
      'Context window management',
      'Request queuing and prioritization'
    ],
    solutions: [
      'Implementing KV-caching with PagedAttention (vLLM)',
      'Global load balancing across multi-region GPU clusters',
      'Semantic caching for redundant queries',
      'Dynamic batching to maximize throughput'
    ],
    diagram: 'User -> LB -> API Gateway -> Inference Engine (vLLM) -> GPU Cluster'
  },
  {
    id: '2',
    title: 'Microservices Inference Architecture',
    icon: Server,
    description: 'Decoupled system design for modular AI capabilities and independent model scaling.',
    challenges: [
      'Inter-service latency',
      'Model versioning',
      'Data consistency',
      'Observability'
    ],
    solutions: [
      'gRPC for high-performance service communication',
      'Model registry with A/B testing capabilities',
      'Event-driven architecture for asynchronous tasks',
      'Centralized logging and tracing (OpenTelemetry)'
    ],
    diagram: 'Gateway -> [Auth Service, Model Service A, Model Service B] -> Vector DB'
  },
  {
    id: '3',
    title: 'GPU Allocation Strategy',
    icon: Cpu,
    description: 'Optimizing hardware utilization and cost through intelligent workload distribution.',
    challenges: [
      'Hardware fragmentation',
      'Idle time costs',
      'Priority preemption',
      'Cold starts'
    ],
    solutions: [
      'Kubernetes-based GPU scheduling',
      'Fractional GPU allocation for smaller models',
      'Auto-scaling based on queue depth',
      'Spot instance utilization for non-critical tasks'
    ],
    diagram: 'Scheduler -> Node Pool -> [A100, H100, L40S] -> Workloads'
  },
  {
    id: '4',
    title: 'Prompt Security Architecture',
    icon: Shield,
    description: 'Multi-layered defense against prompt injection, data leakage, and adversarial attacks.',
    challenges: [
      'Prompt injection',
      'PII leakage',
      'Jailbreaking',
      'Output hallucination'
    ],
    solutions: [
      'Input sanitization and guardrail models',
      'DLP (Data Loss Prevention) scanning',
      'Strict context isolation',
      'Adversarial testing in CI/CD pipelines'
    ],
    diagram: 'Input -> Guardrail -> [LLM] -> DLP Scanner -> Output'
  }
];

export default function SystemDesign() {
  const [selectedId, setSelectedId] = useState<string | null>(null);

  return (
    <div className="max-w-6xl mx-auto py-12 space-y-12">
      <header className="space-y-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-mono uppercase tracking-widest"
        >
          <Layout size={12} />
          Architecture Patterns
        </motion.div>
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">System Design Case Studies</h1>
        <p className="text-xl text-muted-foreground max-w-3xl">
          Deep dives into the architectural decisions and trade-offs required to build production-grade AI systems at scale.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {CASE_STUDIES.map((study) => (
          <motion.div
            key={study.id}
            layoutId={study.id}
            onClick={() => setSelectedId(study.id)}
            className="group p-8 rounded-3xl border border-border bg-card/30 cursor-pointer hover:border-primary/30 hover:bg-card/50 transition-all"
          >
            <div className="flex justify-between items-start mb-6">
              <div className="p-3 rounded-2xl bg-primary/10 text-primary group-hover:scale-110 transition-transform">
                <study.icon size={24} />
              </div>
              <ChevronRight className="text-muted-foreground group-hover:text-primary transition-colors" />
            </div>
            <h3 className="text-2xl font-bold mb-3">{study.title}</h3>
            <p className="text-muted-foreground line-clamp-2">{study.description}</p>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {selectedId && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedId(null)}
              className="fixed inset-0 bg-background/80 backdrop-blur-md z-40"
            />
            <motion.div 
              layoutId={selectedId}
              className="fixed inset-x-4 top-20 bottom-20 md:inset-x-20 md:top-24 md:bottom-24 bg-card border border-border rounded-3xl z-50 overflow-y-auto shadow-2xl"
            >
              <div className="p-8 md:p-12 space-y-12">
                <div className="flex justify-between items-start">
                  <div className="space-y-4">
                    <div className="p-4 rounded-2xl bg-primary/10 text-primary inline-block">
                      {React.createElement(CASE_STUDIES.find(s => s.id === selectedId)!.icon, { size: 32 })}
                    </div>
                    <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight">
                      {CASE_STUDIES.find(s => s.id === selectedId)?.title}
                    </h2>
                  </div>
                  <button 
                    onClick={() => setSelectedId(null)}
                    className="p-2 rounded-full hover:bg-muted transition-colors"
                  >
                    <Zap size={24} />
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="space-y-8">
                    <section className="space-y-4">
                      <h4 className="text-sm font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                        <Info size={14} /> The Challenge
                      </h4>
                      <ul className="space-y-3">
                        {CASE_STUDIES.find(s => s.id === selectedId)?.challenges.map((c, i) => (
                          <li key={i} className="flex items-start gap-3 text-muted-foreground">
                            <span className="h-1.5 w-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                            {c}
                          </li>
                        ))}
                      </ul>
                    </section>

                    <section className="space-y-4">
                      <h4 className="text-sm font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                        <Zap size={14} /> The Solution
                      </h4>
                      <ul className="space-y-3">
                        {CASE_STUDIES.find(s => s.id === selectedId)?.solutions.map((s, i) => (
                          <li key={i} className="flex items-start gap-3 text-muted-foreground">
                            <span className="h-1.5 w-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                            {s}
                          </li>
                        ))}
                      </ul>
                    </section>
                  </div>

                  <div className="space-y-8">
                    <section className="space-y-4 p-8 rounded-2xl bg-muted/30 border border-border">
                      <h4 className="text-sm font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                        <Share2 size={14} /> Architecture Flow
                      </h4>
                      <div className="font-mono text-xs p-4 rounded-lg bg-background border border-border leading-loose">
                        {CASE_STUDIES.find(s => s.id === selectedId)?.diagram}
                      </div>
                      <p className="text-xs text-muted-foreground italic">
                        * Simplified representation of the production request lifecycle.
                      </p>
                    </section>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-6 rounded-2xl border border-border bg-card/50">
                        <div className="text-2xl font-bold">99.9%</div>
                        <div className="text-[10px] font-mono uppercase text-muted-foreground">Availability</div>
                      </div>
                      <div className="p-6 rounded-2xl border border-border bg-card/50">
                        <div className="text-2xl font-bold">&lt;200ms</div>
                        <div className="text-[10px] font-mono uppercase text-muted-foreground">P99 Latency</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
