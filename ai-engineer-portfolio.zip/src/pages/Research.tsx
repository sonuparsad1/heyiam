import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BookOpen, ExternalLink, Search, Tag, ChevronRight, Bookmark, Clock } from 'lucide-react';

const PAPERS = [
  {
    id: '1',
    title: 'Attention Is All You Need',
    authors: 'Vaswani et al.',
    year: 2017,
    tags: ['Transformer', 'NLP', 'Deep Learning'],
    summary: 'The foundational paper introducing the Transformer architecture, replacing RNNs/CNNs with self-attention mechanisms for sequence modeling.',
    arxiv: 'https://arxiv.org/abs/1706.03762',
    progress: 100,
    category: 'Architecture'
  },
  {
    id: '2',
    title: 'LoRA: Low-Rank Adaptation of Large Language Models',
    authors: 'Hu et al.',
    year: 2021,
    tags: ['Fine-tuning', 'Efficiency', 'PEFT'],
    summary: 'Proposes an efficient fine-tuning method that freezes pre-trained weights and injects trainable low-rank matrices into Transformer layers.',
    arxiv: 'https://arxiv.org/abs/2106.09685',
    progress: 85,
    category: 'Optimization'
  },
  {
    id: '3',
    title: 'Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks',
    authors: 'Lewis et al.',
    year: 2020,
    tags: ['RAG', 'Knowledge', 'NLP'],
    summary: 'Introduces RAG, a framework that combines pre-trained parametric memory with non-parametric memory (retrieved documents) for enhanced generation.',
    arxiv: 'https://arxiv.org/abs/2005.11401',
    progress: 90,
    category: 'Systems'
  },
  {
    id: '4',
    title: 'Direct Preference Optimization: Your Language Model is Secretly a Reward Model',
    authors: 'Rafailov et al.',
    year: 2023,
    tags: ['RLHF', 'Alignment', 'DPO'],
    summary: 'A simpler alternative to RLHF that optimizes the policy directly on preference data without training a separate reward model.',
    arxiv: 'https://arxiv.org/abs/2305.18290',
    progress: 60,
    category: 'Alignment'
  }
];

export default function Research() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const allTags = useMemo(() => {
    const tags = new Set<string>();
    PAPERS.forEach(p => p.tags.forEach(t => tags.add(t)));
    return Array.from(tags);
  }, []);

  const filteredPapers = useMemo(() => {
    return PAPERS.filter(paper => {
      const matchesSearch = paper.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           paper.summary.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesTag = !selectedTag || paper.tags.includes(selectedTag);
      return matchesSearch && matchesTag;
    });
  }, [searchQuery, selectedTag]);

  return (
    <div className="max-w-5xl mx-auto py-12 space-y-12">
      <header className="space-y-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-mono uppercase tracking-widest"
        >
          <BookOpen size={12} />
          Knowledge Base
        </motion.div>
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">Research Tracker</h1>
        <p className="text-xl text-muted-foreground max-w-2xl">
          Curated list of pivotal AI research papers I've analyzed, with personal summaries and implementation notes.
        </p>
      </header>

      <div className="flex flex-col md:flex-row gap-6 items-start md:items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
          <input 
            type="text"
            placeholder="Search papers, summaries..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-border bg-card/50 focus:ring-2 focus:ring-primary/20 outline-none transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <button 
            onClick={() => setSelectedTag(null)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${!selectedTag ? 'bg-primary text-primary-foreground' : 'bg-muted hover:bg-muted/80'}`}
          >
            All
          </button>
          {allTags.map(tag => (
            <button 
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${selectedTag === tag ? 'bg-primary text-primary-foreground' : 'bg-muted hover:bg-muted/80'}`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {filteredPapers.map((paper) => (
          <motion.div 
            layout
            key={paper.id}
            className="group rounded-2xl border border-border bg-card/30 overflow-hidden hover:border-primary/30 transition-all"
          >
            <div 
              className="p-6 cursor-pointer flex items-center justify-between"
              onClick={() => setExpandedId(expandedId === paper.id ? null : paper.id)}
            >
              <div className="space-y-2 flex-1">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono text-muted-foreground">{paper.year}</span>
                  <span className="px-2 py-0.5 rounded bg-muted text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{paper.category}</span>
                </div>
                <h3 className="text-xl font-bold group-hover:text-primary transition-colors">{paper.title}</h3>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1"><Bookmark size={14} /> {paper.authors}</span>
                  <span className="flex items-center gap-1"><Clock size={14} /> {paper.progress}% read</span>
                </div>
              </div>
              <ChevronRight 
                className={`text-muted-foreground transition-transform duration-300 ${expandedId === paper.id ? 'rotate-90' : ''}`} 
              />
            </div>

            <AnimatePresence>
              {expandedId === paper.id && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="px-6 pb-6 border-t border-border/50 bg-muted/20"
                >
                  <div className="pt-6 space-y-6">
                    <div className="space-y-2">
                      <h4 className="text-sm font-bold uppercase tracking-widest text-primary">Summary</h4>
                      <p className="text-muted-foreground leading-relaxed">{paper.summary}</p>
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      {paper.tags.map(tag => (
                        <span key={tag} className="flex items-center gap-1 px-2 py-1 rounded-md bg-background border border-border text-[10px] font-mono">
                          <Tag size={10} /> {tag}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-border/50">
                      <div className="w-48 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary" style={{ width: `${paper.progress}%` }} />
                      </div>
                      <a 
                        href={paper.arxiv} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 text-sm font-bold hover:text-primary transition-colors"
                      >
                        ArXiv <ExternalLink size={14} />
                      </a>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
